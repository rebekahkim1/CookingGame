package finalprojectgui;

import java.text.DecimalFormat;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Border;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Shape;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 *
 * @author rebekahkim
 */
public class BrowniePane extends Pane {
    private Button bRecipeButton;
    private Label step1;
    private Label step2;
    private Slider ovenTempSlider;
    private Double temp;
    private Label ovenTempLabel;
    private CheckBox butter;
    private CheckBox sugar;
    private CheckBox eggs;
    private CheckBox vanilla;
    private CheckBox cocoa;
    private CheckBox flour;
    private CheckBox chips;
    private Image butterImage;
    private Image sugarImage;
    private Image eggsImage;
    private Image vanillaImage;
    private Image cocoaImage;
    private Image flourImage;
    private Image chipsImage;
    private ImageView butterView;
    private ImageView sugarView;
    private ImageView eggsView;
    private ImageView vanillaView;
    private ImageView cocoaView;
    private ImageView flourView;
    private ImageView chipsView;
    private Image onOvenImage;
    private ImageView onOvenView;
    private FinalProject ovenTemp;
    private Label step3a;
    private Label step3;
    private Label measureLabel;
    private Image butterImage2;
    private Image sugarImage2;
    private Image eggsImage2;
    private Image vanillaImage2;
    private ImageView butterView2;
    private ImageView sugarView2;
    private ImageView eggsView2;
    private ImageView vanillaView2;
    private Label measureButterLabel;
    private Label measureSugarLabel;
    private Label measureEggsLabel;
    private Label measureVanillaLabel;
    private Label step4;
    private Image butterBowlImage;
    private Image sugarBowlImage;
    private Image eggsBowlImage;
    private Image vanillaBowlImage;
    private Image cocoaBowlImage;
    private Image flourBowlImage;
    private Image chipsBowlImage;
    private ImageView butterBowlView;
    private ImageView sugarBowlView;
    private ImageView eggsBowlView;
    private ImageView vanillaBowlView;
    private ImageView cocoaBowlImageView;
    private ImageView flourBowlImageView;
    private ImageView chipsBowlImageView;
    private Image mixedBowl;
    private ImageView mixedBowlView;
    private Image whiskImage;
    private ImageView whiskView;
    private Circle bowlCircle;
    private Circle whiskCircle;
    private Image panImage;
    private ImageView panImageView;
    private Button step4Button;
    private Image openOvenImage;
    private ImageView openOvenView;
    private Image filledPanImage;
    private ImageView filledPanView;
    private Image cocoaImage2;
    private Image flourImage2;
    private Image chipsImage2;
    private ImageView cocoaView2;
    private ImageView flourView2;
    private ImageView chipsView2;
    private Label measureCocoaLabel;
    private Label measureFlourLabel;
    private Label measureChipsLabel;
    private Button step3Button;
    private Button step5Button;
    private Label step5;
    private Circle ovenCircle;
    private Circle panCircle;
    private Label ovenTimer;
    private TextField timerTextField;
    private Label step6a;
    private Label step6b;
    private Image uncutBrownieImage;
    private ImageView uncutBrownieView;
    private Image cutBrownieImage;
    private ImageView cutBrownieView;
    private Image drizzleImage;
    private ImageView drizzleView;
    private Image toppedImage;
    private ImageView toppedView;
    private Button cutButton;
    private Button serveButton;
    private Image finalBrownieImage;
    private ImageView finalBrownieView;
    private Label doneLabel;
    private Label drizzleLabel;
    private Label sugarLabel;
    
    public BrowniePane() {
        // Recipe Button that displays the window for the recipe
        bRecipeButton = new Button("Click here for the Brownie Recipe");   
        Font labelFont2 = Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20);       
        bRecipeButton.setFont(labelFont2);
        bRecipeButton.setTextFill(Color.ROSYBROWN);
        bRecipeButton.setPrefWidth(1200);                   
        bRecipeButton.setWrapText(true); 
        getChildren().add(bRecipeButton);
        
        bRecipeButton.setOnAction(this::processButtonPress);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // step 1 (oven image and slider)
        
        step1 = new Label("Step 1: Slide the temperature bar to preheat the oven.");
        Font brownieFont = Font.font("Courier New", FontWeight.BOLD, 24);       
        step1.setFont(brownieFont);
        step1.setTextFill(Color.DARKSEAGREEN);
        step1.setPrefWidth(1200);                   
        step1.setWrapText(true); 
        step1.setLayoutY(50);
        getChildren().add(step1);
        
        onOvenImage = new Image("file:onOven.png");
        onOvenView = new ImageView(onOvenImage);
        onOvenView.setPreserveRatio(true);                                                             
        onOvenView.setFitHeight(500);
        onOvenView.setLayoutY(200);
        onOvenView.setLayoutX(300);
        getChildren().add(onOvenView);
        
        temp = 0.0;
        ovenTempSlider = new Slider(0, 450, temp);
        SliderListener sliderListener = new SliderListener();  
        ovenTempSlider.valueProperty().addListener(sliderListener);
        ovenTempSlider.setPrefWidth(900);
        ovenTempLabel = new Label("Temperature: " + temp);
        Font sliderFont = Font.font("Arial Narrow", 20);   
        ovenTempLabel.setFont(sliderFont);
        ovenTempLabel.setLayoutY(100);
        ovenTempLabel.setLayoutX(20);
        ovenTempSlider.setLayoutY(100);
        ovenTempSlider.setLayoutX(150);
        getChildren().addAll(ovenTempLabel, ovenTempSlider);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // step 2 (ingredient checkboxes)
        
        step2 = new Label("Step 2: Choose the ingredients needed for step 2 in the Brownie Recipe.");   
        step2.setFont(brownieFont);
        step2.setTextFill(Color.DARKSEAGREEN);
        step2.setPrefWidth(1200);                   
        step2.setWrapText(true); 
        step2.setVisible(false);
        step2.setLayoutY(50);
        getChildren().add(step2);
        
        butter = new CheckBox("Butter");
        Font ingredientFont = Font.font("Helvetica", FontWeight.BOLD, 18);       
        butter.setFont(ingredientFont);
        butter.setTextFill(Color.DARKSLATEGRAY);
        butter.setPrefWidth(120); 
        butter.setLayoutY(100);
        butter.setLayoutX(50);
        butterImage = new Image("file:butter.png");
        butterView = new ImageView(butterImage);
        butterView.setPreserveRatio(true);                                                             
        butterView.setFitHeight(130); 
        butterView.setLayoutY(130);
        butterView.setLayoutX(50);
        butter.setVisible(false);
        butterView.setVisible(false);
        
        sugar = new CheckBox("Sugar");
        sugar.setFont(ingredientFont);
        sugar.setTextFill(Color.DARKSLATEGRAY);
        sugar.setPrefWidth(100); 
        sugar.setLayoutY(300);
        sugar.setLayoutX(50);
        sugarImage = new Image("file:sugar.png");
        sugarView = new ImageView(sugarImage);
        sugarView.setPreserveRatio(true);                                                             
        sugarView.setFitHeight(140);   
        sugarView.setLayoutY(330);
        sugarView.setLayoutX(50);
        sugar.setVisible(false);
        sugarView.setVisible(false);
        
        eggs = new CheckBox("Eggs");
        eggs.setFont(ingredientFont);
        eggs.setTextFill(Color.DARKSLATEGRAY);
        eggs.setPrefWidth(120); 
        eggs.setLayoutY(300);
        eggs.setLayoutX(650);
        eggsImage = new Image("file:eggs.png");
        eggsView = new ImageView(eggsImage);
        eggsView.setPreserveRatio(true);                                                             
        eggsView.setFitHeight(120); 
        eggsView.setLayoutY(330);
        eggsView.setLayoutX(650);
        eggs.setVisible(false);
        eggsView.setVisible(false);
        
        vanilla = new CheckBox("Vanilla Extract");
        vanilla.setFont(ingredientFont);
        vanilla.setTextFill(Color.DARKSLATEGRAY);
        vanilla.setPrefWidth(300);
        vanilla.setLayoutY(100);
        vanilla.setLayoutX(950);
        vanillaImage = new Image("file:vanilla.png");
        vanillaView = new ImageView(vanillaImage);
        vanillaView.setPreserveRatio(true);                                                             
        vanillaView.setFitHeight(130);  
        vanillaView.setLayoutY(130);
        vanillaView.setLayoutX(950);
        vanilla.setVisible(false);
        vanillaView.setVisible(false);
        
        cocoa = new CheckBox("Cocoa Powder");
        cocoa.setFont(ingredientFont);
        cocoa.setTextFill(Color.DARKSLATEGRAY);
        cocoa.setPrefWidth(300);
        cocoa.setLayoutY(100);
        cocoa.setLayoutX(350);
        cocoaImage = new Image("file:cocoa.png");
        cocoaView = new ImageView(cocoaImage);
        cocoaView.setPreserveRatio(true); 
        cocoaView.setFitHeight(120);
        cocoa.setVisible(false);
        cocoaView.setLayoutY(130);
        cocoaView.setLayoutX(350);
        cocoaView.setVisible(false);
        
        flour = new CheckBox("All-Purpose Flour");
        flour.setFont(ingredientFont);
        flour.setTextFill(Color.DARKSLATEGRAY);
        flour.setPrefWidth(300); 
        flour.setLayoutY(300);
        flour.setLayoutX(350);
        flourImage = new Image("file:flour.png");
        flourView = new ImageView(flourImage);
        flourView.setPreserveRatio(true);                                                             
        flourView.setFitHeight(140);   
        flourView.setLayoutY(330);
        flourView.setLayoutX(350);
        flour.setVisible(false);
        flourView.setVisible(false);
        
        chips = new CheckBox("Chocolate Chips");
        chips.setFont(ingredientFont);
        chips.setTextFill(Color.DARKSLATEGRAY);
        chips.setPrefWidth(300); 
        chips.setLayoutY(100);
        chips.setLayoutX(650);
        chipsImage = new Image("file:chips.png");
        chipsView = new ImageView(chipsImage);
        chipsView.setPreserveRatio(true);                                                             
        chipsView.setFitHeight(140); 
        chipsView.setLayoutY(130);
        chipsView.setLayoutX(650);
        chips.setVisible(false);
        chipsView.setVisible(false);
        
        getChildren().addAll(butter, cocoa, sugar, vanilla, eggs, chips, flour,
                butterView, cocoaView, sugarView, vanillaView, 
                eggsView, chipsView, flourView);
        
        // connecting to checkboxes to event handler
        butter.setOnAction(this::processCheckBoxes);
        sugar.setOnAction(this::processCheckBoxes);
        vanilla.setOnAction(this::processCheckBoxes);
        eggs.setOnAction(this::processCheckBoxes);
        
        // measuring each ingredient with label and images
        measureLabel = new Label("Click each ingredient according to how much the recipe calls for:");    
        measureLabel.setFont(brownieFont);
        measureLabel.setTextFill(Color.DARKSEAGREEN);
        measureLabel.setPrefWidth(1200);     
        measureLabel.setLayoutY(50);
        measureLabel.setWrapText(true); 
        measureLabel.setVisible(false);
        
        measureButterLabel = new Label("Click the # of Cups Needed:");
        measureButterLabel.setFont(ingredientFont);
        measureButterLabel.setTextFill(Color.DARKBLUE);
        measureButterLabel.setPrefWidth(1200); 
        measureButterLabel.setLayoutY(90);
        butterImage2 = new Image("file:butter.png");
        butterView2 = new ImageView(butterImage2);
        butterView2.setPreserveRatio(true);                                                             
        butterView2.setFitHeight(150); 
        butterView2.setLayoutY(130);
        butterView2.setLayoutX(600);
        measureButterLabel.setVisible(false);
        butterView2.setVisible(false);
        
        measureSugarLabel = new Label("Click the # of Cups Needed:");
        measureSugarLabel.setFont(ingredientFont);
        measureSugarLabel.setTextFill(Color.DARKBLUE);
        measureSugarLabel.setPrefWidth(1200); 
        measureSugarLabel.setLayoutY(90);
        sugarImage2 = new Image("file:sugar.png");
        sugarView2 = new ImageView(sugarImage2);
        sugarView2.setPreserveRatio(true);                                                             
        sugarView2.setFitHeight(150);   
        sugarView2.setLayoutY(130);
        sugarView2.setLayoutX(600);
        sugarView2.setRotate(-130);
        measureSugarLabel.setVisible(false);
        sugarView2.setVisible(false);
        
        measureEggsLabel = new Label("Click the # of Eggs Needed:");
        measureEggsLabel.setFont(ingredientFont);
        measureEggsLabel.setTextFill(Color.DARKBLUE);
        measureEggsLabel.setPrefWidth(1200); 
        measureEggsLabel.setLayoutY(90);
        eggsImage2 = new Image("file:eggs.png");
        eggsView2 = new ImageView(eggsImage2);
        eggsView2.setPreserveRatio(true);                                                             
        eggsView2.setFitHeight(150); 
        eggsView2.setLayoutY(130);
        eggsView2.setLayoutX(600);
        eggsView2.setRotate(0);
        measureEggsLabel.setVisible(false);
        eggsView2.setVisible(false);
        
        measureVanillaLabel = new Label("Click the # of Drops Needed:");
        measureVanillaLabel.setFont(ingredientFont);
        measureVanillaLabel.setTextFill(Color.DARKBLUE);
        measureVanillaLabel.setPrefWidth(1200); 
        measureVanillaLabel.setLayoutY(90);
        vanillaImage2 = new Image("file:vanilla.png");
        vanillaView2 = new ImageView(vanillaImage2);
        vanillaView2.setPreserveRatio(true);                                                             
        vanillaView2.setFitHeight(150);  
        vanillaView2.setLayoutY(130);
        vanillaView2.setLayoutX(600);
        vanillaView2.setRotate(-130);
        measureVanillaLabel.setVisible(false);
        vanillaView2.setVisible(false);
        
        // connecting mouse click on images to the event handlers
        butterView2.setOnMouseClicked(this::processMouseClick);
        sugarView2.setOnMouseClicked(this::processMouseClick2);
        eggsView2.setOnMouseClicked(this::processMouseClick3);
        vanillaView2.setOnMouseClicked(this::processMouseClick4);
        
        getChildren().addAll(measureLabel, measureButterLabel, measureSugarLabel, 
                measureEggsLabel, measureVanillaLabel, butterView2, sugarView2,
                eggsView2, vanillaView2);
        
        // images that show the change of the bowl as each ingredient is added
        butterBowlImage = new Image("file:butterBowl.PNG");
        butterBowlView = new ImageView(butterBowlImage);
        butterBowlView.setPreserveRatio(true);                                                             
        butterBowlView.setFitHeight(400);  
        butterBowlView.setVisible(false);
        butterBowlView.setLayoutY(300);
        butterBowlView.setLayoutX(300);
        
        sugarBowlImage = new Image("file:sugarBowl.PNG");
        sugarBowlView = new ImageView(sugarBowlImage);
        sugarBowlView.setPreserveRatio(true);                                                             
        sugarBowlView.setFitHeight(400);  
        sugarBowlView.setVisible(false);
        sugarBowlView.setLayoutY(300);
        sugarBowlView.setLayoutX(300);
        
        eggsBowlImage = new Image("file:eggBowl.PNG");
        eggsBowlView = new ImageView(eggsBowlImage);
        eggsBowlView.setPreserveRatio(true);                                                             
        eggsBowlView.setFitHeight(400);  
        eggsBowlView.setVisible(false);
        eggsBowlView.setLayoutY(300);
        eggsBowlView.setLayoutX(300);
        
        vanillaBowlImage = new Image("file:vanillaBowl.PNG");
        vanillaBowlView = new ImageView(vanillaBowlImage);
        vanillaBowlView.setPreserveRatio(true);                                                             
        vanillaBowlView.setFitHeight(400);  
        vanillaBowlView.setVisible(false);
        vanillaBowlView.setLayoutY(300);
        vanillaBowlView.setLayoutX(300);
        
        // images and shapes for dragging whisk image and circle to bowl image and circle
        
        step3 = new Label("Mix the ingredients by dragging the whisk to the bowl.");
        step3.setFont(brownieFont);
        step3.setTextFill(Color.DARKSEAGREEN);
        step3.setPrefWidth(1000);                   
        step3.setWrapText(true); 
        step3.setVisible(false);
        step3.setLayoutY(50);
        getChildren().add(step3);
        
        getChildren().addAll(butterBowlView, sugarBowlView, eggsBowlView, vanillaBowlView);
        
        bowlCircle = new Circle(550, 300, 50);
        bowlCircle.setFill(Color.TRANSPARENT);
        bowlCircle.setStroke(Color.TRANSPARENT);
        bowlCircle.setVisible(false);
        
        whiskCircle = new Circle(200, 250, 50);
        whiskCircle.setFill(Color.TRANSPARENT);
        whiskCircle.setStroke(Color.TRANSPARENT);
        whiskCircle.setVisible(false);
        
        whiskImage = new Image("file:whisk.png");
        whiskView = new ImageView(whiskImage);
        whiskView.setPreserveRatio(true);                                                             
        whiskView.setFitHeight(300);  
        whiskView.setLayoutY(120);
        whiskView.setLayoutX(100);
        whiskView.setVisible(false);
        
        getChildren().addAll(bowlCircle, whiskCircle, whiskView);
        
        whiskView.setOnMouseDragged(this::processMouseDrag);
        
        mixedBowl = new Image("file:mixedBowl_1.PNG");
        mixedBowlView = new ImageView(mixedBowl);
        mixedBowlView.setPreserveRatio(true);                                                             
        mixedBowlView.setFitHeight(400);  
        mixedBowlView.setLayoutY(300);
        mixedBowlView.setLayoutX(300);
        mixedBowlView.setVisible(false);
        getChildren().add(mixedBowlView);

        //-------------------------------------------------------------------------------------------------------------------------
        // step 3 (checkboxes for new ingredients)
        
        step3Button = new Button("Click here for Step 3");       
        step3Button.setFont(labelFont2);
        step3Button.setTextFill(Color.CADETBLUE);
        step3Button.setPrefWidth(400);                   
        step3Button.setWrapText(true); 
        step3Button.setLayoutX(400);
        step3Button.setLayoutY(100);
        step3Button.setVisible(false);
        getChildren().add(step3Button);
        
        step3Button.setOnAction(this::processButtonPress2);
        
        step3a = new Label("Step 3: Choose ingredients needed for step 3:");
        step3a.setFont(brownieFont);
        step3a.setTextFill(Color.DARKSEAGREEN);
        step3a.setPrefWidth(1000);                   
        step3a.setWrapText(true); 
        step3a.setVisible(false);
        step3a.setLayoutY(50);
        getChildren().add(step3a);
        
        // connecting event handlers to new checkboxes
        cocoa.setOnAction(this::processCheckBoxes2);
        flour.setOnAction(this::processCheckBoxes2);
        chips.setOnAction(this::processCheckBoxes2);
        
        // images and labels for adding ingredients in the bowl and changes in the bowl
        cocoaBowlImage = new Image("file:cocoaBowl.PNG");
        cocoaBowlImageView = new ImageView(cocoaBowlImage);
        cocoaBowlImageView.setPreserveRatio(true);                                                             
        cocoaBowlImageView.setFitHeight(400);  
        cocoaBowlImageView.setVisible(false);
        cocoaBowlImageView.setLayoutY(300);
        cocoaBowlImageView.setLayoutX(300);
        
        flourBowlImage = new Image("file:flourBowl.PNG");
        flourBowlImageView = new ImageView(flourBowlImage);
        flourBowlImageView.setPreserveRatio(true);                                                             
        flourBowlImageView.setFitHeight(400);  
        flourBowlImageView.setVisible(false);
        flourBowlImageView.setLayoutY(300);
        flourBowlImageView.setLayoutX(300);
        
        chipsBowlImage = new Image("file:chipsBowl.PNG");
        chipsBowlImageView = new ImageView(chipsBowlImage);
        chipsBowlImageView.setPreserveRatio(true);                                                             
        chipsBowlImageView.setFitHeight(400);  
        chipsBowlImageView.setVisible(false);
        chipsBowlImageView.setLayoutY(300);
        chipsBowlImageView.setLayoutX(300);
        
        measureCocoaLabel = new Label("Click the # of Cups Needed:");
        measureCocoaLabel.setFont(ingredientFont);
        measureCocoaLabel.setTextFill(Color.DARKBLUE);
        measureCocoaLabel.setPrefWidth(1200); 
        measureCocoaLabel.setLayoutY(90);
        cocoaImage2 = new Image("file:cocoa.png");
        cocoaView2 = new ImageView(cocoaImage2);
        cocoaView2.setPreserveRatio(true);                                                             
        cocoaView2.setFitHeight(150);   
        cocoaView2.setLayoutY(130);
        cocoaView2.setLayoutX(600);
        cocoaView2.setRotate(-130);
        measureCocoaLabel.setVisible(false);
        cocoaView2.setVisible(false);
        
        measureFlourLabel = new Label("Click the # of Cups Needed:");
        measureFlourLabel.setFont(ingredientFont);
        measureFlourLabel.setTextFill(Color.DARKBLUE);
        measureFlourLabel.setPrefWidth(1200); 
        measureFlourLabel.setLayoutY(90);
        flourImage2 = new Image("file:flour.png");
        flourView2 = new ImageView(flourImage2);
        flourView2.setPreserveRatio(true);                                                             
        flourView2.setFitHeight(150); 
        flourView2.setLayoutY(130);
        flourView2.setLayoutX(600);
        flourView2.setRotate(0);
        measureFlourLabel.setVisible(false);
        flourView2.setVisible(false);
        
        measureChipsLabel = new Label("Click the # of Cups Needed:");
        measureChipsLabel.setFont(ingredientFont);
        measureChipsLabel.setTextFill(Color.DARKBLUE);
        measureChipsLabel.setPrefWidth(1200); 
        measureChipsLabel.setLayoutY(90);
        chipsImage2 = new Image("file:chips.png");
        chipsView2 = new ImageView(chipsImage2);
        chipsView2.setPreserveRatio(true);                                                             
        chipsView2.setFitHeight(150);  
        chipsView2.setLayoutY(130);
        chipsView2.setLayoutX(600);
        chipsView2.setRotate(-70);
        measureChipsLabel.setVisible(false);
        chipsView2.setVisible(false);
        
        getChildren().addAll(cocoaBowlImageView, flourBowlImageView, chipsBowlImageView,
                measureCocoaLabel, cocoaView2, measureFlourLabel, 
                flourView2, measureChipsLabel, chipsView2);
        
        cocoaView2.setOnMouseClicked(this::processMouseClick5);
        flourView2.setOnMouseClicked(this::processMouseClick6);
        chipsView2.setOnMouseClicked(this::processMouseClick7);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // step 4
        
        step4Button = new Button("Click here for Step 4");       
        step4Button.setFont(labelFont2);
        step4Button.setTextFill(Color.CADETBLUE);
        step4Button.setPrefWidth(400);                   
        step4Button.setWrapText(true); 
        step4Button.setLayoutX(400);
        step4Button.setLayoutY(100);
        step4Button.setVisible(false);
        getChildren().add(step4Button);
        
        step4Button.setOnAction(this::processButtonPress3);
        
        step4 = new Label("Step 4: Pour mixture into the pan by clicking on the bowl 7 times.");
        step4.setFont(brownieFont);
        step4.setTextFill(Color.DARKSEAGREEN);
        step4.setPrefWidth(1200);                   
        step4.setWrapText(true); 
        step4.setVisible(false);
        step4.setLayoutY(50);
        getChildren().add(step4);
        
        panImage = new Image("file:emptyPan.png");
        panImageView = new ImageView(panImage);
        panImageView.setPreserveRatio(true);                                                             
        panImageView.setFitHeight(300);  
        panImageView.setLayoutY(400);
        panImageView.setLayoutX(200);
        panImageView.setVisible(false);
        getChildren().add(panImageView);
        
        mixedBowlView.setOnMouseClicked(this::processMouseRotate);
        
        // images for oven and pan 
        openOvenImage = new Image("file:openOven.jpeg");
        openOvenView = new ImageView(openOvenImage);
        openOvenView.setPreserveRatio(true);                                                             
        openOvenView.setFitHeight(600);  
        openOvenView.setLayoutY(100);
        openOvenView.setLayoutX(300);
        openOvenView.setVisible(false);
        getChildren().add(openOvenView);
        
        filledPanImage = new Image("file:filledPan.png");
        filledPanView = new ImageView(filledPanImage);
        filledPanView.setPreserveRatio(true);                                                             
        filledPanView.setFitHeight(300);  
        filledPanView.setLayoutY(400);
        filledPanView.setLayoutX(200);
        filledPanView.setVisible(false);
        getChildren().add(filledPanView);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // step 5
        
        step5Button = new Button("Click here for Step 5");       
        step5Button.setFont(labelFont2);
        step5Button.setTextFill(Color.CADETBLUE);
        step5Button.setPrefWidth(300);                   
        step5Button.setWrapText(true); 
        step5Button.setLayoutX(800);
        step5Button.setLayoutY(600);
        step5Button.setVisible(false);
        getChildren().add(step5Button);
        
        step5Button.setOnAction(this::processButtonPress4);
        
        step5 = new Label("Step 5: Put the pan into the oven and set it for 30 minutes.");
        step5.setFont(brownieFont);
        step5.setTextFill(Color.DARKSEAGREEN);
        step5.setPrefWidth(1200);                   
        step5.setWrapText(true); 
        step5.setVisible(false);
        step5.setLayoutY(50);
        getChildren().add(step5);
        
        // circles for interesting the shapes 
        panCircle = new Circle(200, 610, 50);
        panCircle.setFill(Color.TRANSPARENT);
        panCircle.setStroke(Color.TRANSPARENT);
        panCircle.setVisible(false);
        
        ovenCircle = new Circle(600, 400, 50);
        ovenCircle.setFill(Color.TRANSPARENT);
        ovenCircle.setStroke(Color.TRANSPARENT);
        ovenCircle.setVisible(false);
        
        getChildren().addAll(panCircle, ovenCircle);
        filledPanView.setOnMouseDragged(this::processMouseDrag2);
        
        // oven timer label
        ovenTimer = new Label("Oven Timer (type number of minutes)");
        ovenTimer.setFont(brownieFont);
        ovenTimer.setTextFill(Color.DEEPPINK);
        ovenTimer.setPrefWidth(1200);                   
        ovenTimer.setWrapText(true); 
        ovenTimer.setVisible(false);
        ovenTimer.setLayoutY(100);
        ovenTimer.setLayoutX(50);
        getChildren().add(ovenTimer);
        
        // oven timer textField
        timerTextField = new TextField("");
        timerTextField.setFont(brownieFont);
        timerTextField.setPrefWidth(200);     
        timerTextField.setVisible(false);
        timerTextField.setLayoutY(130);
        timerTextField.setLayoutX(50);
        getChildren().add(timerTextField);
        
        timerTextField.setOnAction(this::processTextField);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // step 6
        
        step6a = new Label("Step 6: Cut the brownies into squares.");
        step6a.setFont(brownieFont);
        step6a.setTextFill(Color.DARKSEAGREEN);
        step6a.setPrefWidth(1200);                   
        step6a.setWrapText(true); 
        step6a.setVisible(false);
        step6a.setLayoutY(50);
        getChildren().add(step6a);
        
        uncutBrownieImage = new Image("file:uncutBrownie.png");
        uncutBrownieView = new ImageView(uncutBrownieImage);
        uncutBrownieView.setPreserveRatio(true);                                                             
        uncutBrownieView.setFitHeight(400);  
        uncutBrownieView.setLayoutY(300);
        uncutBrownieView.setLayoutX(300);
        uncutBrownieView.setVisible(false);
        getChildren().add(uncutBrownieView);
        
        // button for cutting the brownies
        cutButton = new Button("Click here to cut brownies");       
        cutButton.setFont(labelFont2);
        cutButton.setTextFill(Color.CADETBLUE);
        cutButton.setPrefWidth(500);                   
        cutButton.setWrapText(true); 
        cutButton.setLayoutX(350);
        cutButton.setLayoutY(150);
        cutButton.setVisible(false);
        getChildren().add(cutButton);
        
        cutButton.setOnAction(this::processButtonPress5);
        
        cutBrownieImage = new Image("file:cutBrownie.png");
        cutBrownieView = new ImageView(cutBrownieImage);
        cutBrownieView.setPreserveRatio(true);                                                             
        cutBrownieView.setFitHeight(400);  
        cutBrownieView.setLayoutY(300);
        cutBrownieView.setLayoutX(300);
        cutBrownieView.setVisible(false);
        getChildren().add(cutBrownieView);
        cutBrownieView.setFocusTraversable(true);
        cutBrownieView.setOnKeyTyped(this::processKeyType);  
        
        //-------------------------------------------------------------------------------------------------------------------------
        // step 7
        
        step6b = new Label("Step 7: Decorate the Brownies with Caramel Drizzle and Powdered Sugar.");
        step6b.setFont(brownieFont);
        step6b.setTextFill(Color.DARKSEAGREEN);
        step6b.setPrefWidth(1200);                   
        step6b.setWrapText(true); 
        step6b.setVisible(false);
        step6b.setLayoutY(50);
        getChildren().add(step6b);
        
        // label and image for brownie with caramel drizzle
        drizzleLabel = new Label("Hit the 'tab' key and then type 'd' to add drizzle");
        drizzleLabel.setFont(ingredientFont);
        drizzleLabel.setTextFill(Color.DARKBLUE);
        drizzleLabel.setPrefWidth(1200); 
        drizzleLabel.setLayoutY(90);
        drizzleLabel.setVisible(false);
        
        drizzleImage = new Image("file:drizzle.png");
        drizzleView = new ImageView(drizzleImage);
        drizzleView.setPreserveRatio(true);                                                             
        drizzleView.setFitHeight(400);  
        drizzleView.setLayoutY(300);
        drizzleView.setLayoutX(300);
        drizzleView.setVisible(false);
        drizzleView.setFocusTraversable(true);
        getChildren().addAll(drizzleView, drizzleLabel);
        drizzleView.setOnKeyTyped(this::processKeyType2);  
        
        // label and image for brownie with sugar
        sugarLabel = new Label("Type 'tab' and then 'p' to add powdered sugar");
        sugarLabel.setFont(ingredientFont);
        sugarLabel.setTextFill(Color.DARKBLUE);
        sugarLabel.setPrefWidth(1200); 
        sugarLabel.setLayoutY(90);
        sugarLabel.setVisible(false);
        
        toppedImage = new Image("file:toppedBrownie.png");
        toppedView = new ImageView(toppedImage);
        toppedView.setPreserveRatio(true);                                                             
        toppedView.setFitHeight(400);  
        toppedView.setLayoutY(300);
        toppedView.setLayoutX(300);
        toppedView.setVisible(false);
        getChildren().addAll(toppedView, sugarLabel);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // final serving
        
        serveButton = new Button("Click here to finish!");       
        serveButton.setFont(labelFont2);
        serveButton.setTextFill(Color.CADETBLUE);
        serveButton.setPrefWidth(300);                   
        serveButton.setWrapText(true); 
        serveButton.setLayoutX(450);
        serveButton.setLayoutY(150);
        serveButton.setVisible(false);
        getChildren().add(serveButton);
        
        serveButton.setOnAction(this::processButtonPress8);
        
        finalBrownieImage = new Image("file:brownieFinal.png");
        finalBrownieView = new ImageView(finalBrownieImage);
        finalBrownieView.setPreserveRatio(true);                                                             
        finalBrownieView.setFitHeight(400);  
        finalBrownieView.setLayoutY(300);
        finalBrownieView.setLayoutX(300);
        finalBrownieView.setVisible(false);
        getChildren().add(finalBrownieView);
        
        doneLabel = new Label("All Done!");
        Font doneFont = new Font("Noteworthy Light", 32);
        doneLabel.setFont(doneFont);
        doneLabel.setTextFill(Color.DEEPPINK);
        doneLabel.setPrefWidth(1200);                   
        doneLabel.setWrapText(true); 
        doneLabel.setVisible(false);
        doneLabel.setLayoutY(100);
        doneLabel.setLayoutX(550);
        getChildren().add(doneLabel);
        
    }

    public BrowniePane(FinalProject ovenTemp) {
        this.ovenTemp = ovenTemp;
    }
    
    // event handler for displaying recipe window when button is pressed
    public void processButtonPress(ActionEvent event) {
        if(event.getSource() == bRecipeButton) {
            Stage recipeWindow = new Stage();  
            BrownieRecipePane brecipePane = new BrownieRecipePane();
            VBox bRecipe = new VBox();  
            bRecipe.getChildren().add(brecipePane); 
            bRecipe.setStyle("-fx-background-color: #f0fff0");
            Scene bScene = new Scene(bRecipe, 400, 800);
            recipeWindow.setScene(bScene);
            recipeWindow.setTitle("Brownie Recipe");
            recipeWindow.show();
            }
            
        }
    
    //-------------------------------------------------------------------------------------------------------------------------
    // step 1 (event listener for oven slider)
    private class SliderListener implements ChangeListener<Number> {

            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                temp = ovenTempSlider.getValue();  
                DecimalFormat fmt = new DecimalFormat("0"); 
                ovenTempLabel.setText("Temperature: " + fmt.format(temp));

                ovenTempSlider.setMajorTickUnit(50);  
                ovenTempSlider.setMinorTickCount(25);  
                ovenTempSlider.setShowTickMarks(true);  
                ovenTempSlider.setShowTickLabels(true);
                
                if(temp > 349.5 && temp < 350.5) {
                    step2.setVisible(true);
                    butter.setVisible(true);
                    cocoa.setVisible(true);
                    sugar.setVisible(true);
                    vanilla.setVisible(true);
                    eggs.setVisible(true);
                    chips.setVisible(true);
                    flour.setVisible(true);
                    butterView.setVisible(true);
                    cocoaView.setVisible(true);
                    sugarView.setVisible(true);
                    vanillaView.setVisible(true);
                    eggsView.setVisible(true);
                    chipsView.setVisible(true);
                    flourView.setVisible(true);
                    
                    getChildren().removeAll(step1, onOvenView, ovenTempLabel, ovenTempSlider);
                }
            }
    }

    //-------------------------------------------------------------------------------------------------------------------------
    // step 2 (event handler for ingredient checkboxes)
    public void processCheckBoxes(ActionEvent event) {
            if(butter.isSelected() && sugar.isSelected() && vanilla.isSelected() && eggs.isSelected()){
                    measureLabel.setVisible(true);
                    measureButterLabel.setVisible(true); 
                    butterView2.setVisible(true);
                    
                    getChildren().removeAll(step2, butter, cocoa, sugar, vanilla, eggs, chips, flour,
                    butterView, cocoaView, sugarView, vanillaView, 
                    eggsView, chipsView, flourView);
                }    
    }
    
    // event handlers for measuring ingredients when clicking on the image
    public void processMouseClick(MouseEvent event) {
        if(event.getSource() == butterView2) {
            butterBowlView.setVisible(true);
            measureSugarLabel.setVisible(true); 
            sugarView2.setVisible(true);
           
            getChildren().removeAll(measureButterLabel, butterView2);
        }
    }
    
    public void processMouseClick2(MouseEvent event) {
        if(event.getClickCount() == 2 && event.getSource() == sugarView2) {
            sugarBowlView.setVisible(true);
            butterBowlView.setVisible(false);
            measureEggsLabel.setVisible(true); 
            eggsView2.setVisible(true);
            
            getChildren().removeAll(measureSugarLabel, sugarView2, butterBowlView);
        }
    }
    
    public void processMouseClick3(MouseEvent event) {
        if(event.getClickCount() == 4 && event.getSource() == eggsView2) {
            sugarBowlView.setVisible(false);
            eggsBowlView.setVisible(true);
            measureVanillaLabel.setVisible(true); 
            vanillaView2.setVisible(true);
            
            getChildren().removeAll(measureEggsLabel, eggsView2, sugarBowlView);
        }
    }
    
    public void processMouseClick4(MouseEvent event) {
        if(event.getClickCount() == 1 && event.getSource() == vanillaView2) {
            eggsBowlView.setVisible(false);
            vanillaBowlView.setVisible(true);
            bowlCircle.setVisible(true);
            step3.setVisible(true);
            whiskCircle.setVisible(true);
            whiskView.setVisible(true);
            
            getChildren().removeAll(measureVanillaLabel, vanillaView2, eggsBowlView, measureLabel);
        }
    }
    
    // event handler for event to occur when the shapes intersect in order to whisk
    public void processMouseDrag(MouseEvent event) {
        if (event.getSource() == whiskView) { 
            double newX = event.getX();
            double newY = event.getY();
            whiskView.setX(newX);
            whiskView.setY(newY);
            whiskCircle.setCenterX(newX + 170);
            whiskCircle.setCenterY(newY + 230);
        }
        if (Shape.intersect(bowlCircle, whiskCircle).getBoundsInLocal().isEmpty() == false) {
            mixedBowlView.setVisible(true);
            step3Button.setVisible(true);
            getChildren().removeAll(whiskView, whiskCircle, step3, bowlCircle, vanillaBowlView);
        }
    }
    
    //-------------------------------------------------------------------------------------------------------------------------
    // step 3 (event handler for step 3 button)
    public void processButtonPress2(ActionEvent event) {
        if(event.getSource() == step3Button) {
            step3a.setVisible(true);
            getChildren().addAll(butter, cocoa, sugar, vanilla, eggs, chips, flour,
                butterView, cocoaView, sugarView, vanillaView, 
                eggsView, chipsView, flourView);
                    butter.setVisible(true);
                    cocoa.setVisible(true);
                    sugar.setVisible(true);
                    vanilla.setVisible(true);
                    eggs.setVisible(true);
                    chips.setVisible(true);
                    flour.setVisible(true);
                    butterView.setVisible(true);
                    cocoaView.setVisible(true);
                    sugarView.setVisible(true);
                    vanillaView.setVisible(true);
                    eggsView.setVisible(true);
                    chipsView.setVisible(true);
                    flourView.setVisible(true);
//            mixedBowlView.setLayoutX(600);
//            mixedBowlView.setLayoutY(100);
//            panImageView.setVisible(true);
            getChildren().removeAll(step3Button, mixedBowlView);
            }
    }
    
    // event handler for other check boxes
    public void processCheckBoxes2(ActionEvent event) {
            if(cocoa.isSelected() && flour.isSelected() && chips.isSelected()){
                getChildren().addAll(mixedBowlView, measureLabel);    
                mixedBowlView.setVisible(true);
                measureLabel.setVisible(true);
                measureCocoaLabel.setVisible(true);
                cocoaView2.setVisible(true);
                    
                    getChildren().removeAll(step3a, butter, cocoa, sugar, vanilla, eggs, chips, flour,
                    butterView, cocoaView, sugarView, vanillaView, 
                    eggsView, chipsView, flourView);
                }    
    }
    
    // event handler for measuring the other ingredients by the user clicking on the images
    public void processMouseClick5(MouseEvent event) {
        if(event.getClickCount() == 1 && event.getSource() == cocoaView2) {
            cocoaBowlImageView.setVisible(true);
            measureFlourLabel.setVisible(true); 
            flourView2.setVisible(true);
           
            getChildren().removeAll(measureCocoaLabel, cocoaView2, mixedBowlView);
        }
    }
    
    public void processMouseClick6(MouseEvent event) {
        if(event.getClickCount() == 1 && event.getSource() == flourView2) {
            flourBowlImageView.setVisible(true);
            cocoaBowlImageView.setVisible(false);
            measureChipsLabel.setVisible(true); 
            chipsView2.setVisible(true);
            
            getChildren().removeAll(measureFlourLabel, flourView2, cocoaBowlImageView);
        }
    }
    
    public void processMouseClick7(MouseEvent event) {
        if(event.getClickCount() == 1 && event.getSource() == chipsView2) {
            flourBowlImageView.setVisible(false);
            chipsBowlImageView.setVisible(true);
            step4Button.setVisible(true);

            getChildren().removeAll(measureLabel, measureChipsLabel, chipsView2, flourBowlImageView, step3a);
        }
    }
    
    //-------------------------------------------------------------------------------------------------------------------------
    // step 4 (event handler for step 4 button)
    public void processButtonPress3(ActionEvent event) {
        if(event.getSource() == step4Button) {
            step4.setVisible(true);
            getChildren().add(mixedBowlView);
            mixedBowlView.setLayoutX(600);
            mixedBowlView.setLayoutY(100);
            panImageView.setVisible(true);
            getChildren().removeAll(chipsBowlImageView, step4Button);
            }
    }
    
    // event handler for rotating the image when the user clicks on the image in order to "pour" the bowl
    public void processMouseRotate(MouseEvent event) {
        if (event.getSource() == mixedBowlView) {  
                mixedBowlView.setRotate(mixedBowlView.getRotate() - 5);  
            if (event.getClickCount() == 7) {
                getChildren().removeAll(panImageView);
                filledPanView.setVisible(true);
                step5Button.setVisible(true);
            }
        }
    }
    
    //-------------------------------------------------------------------------------------------------------------------------
    // step 5 (event handler for step 5 button)
    public void processButtonPress4(ActionEvent event) {
        if(event.getSource() == step5Button) {
            step5.setVisible(true);
            openOvenView.setVisible(true);
            panCircle.setVisible(true);
            ovenCircle.setVisible(true);
            filledPanView.setFitHeight(100);
            filledPanView.setLayoutX(50);
            filledPanView.setLayoutY(550);
            getChildren().removeAll(mixedBowlView, step5Button, step4);
            }
    }
    
    // event handler for dragging pan image to the oven image for the event to occur when
    // the pan circle intersect the oven circle (the circles are transparent)
    public void processMouseDrag2(MouseEvent event) {
        if (event.getSource() == filledPanView) { 
            double secondX = event.getX();
            double secondY = event.getY();
            filledPanView.setX(secondX);
            filledPanView.setY(secondY);
            panCircle.setCenterX(secondX + 50);
            panCircle.setCenterY(secondY + 550);
        }
        if (Shape.intersect(panCircle, ovenCircle).getBoundsInLocal().isEmpty() == false) {
            ovenTimer.setVisible(true);
            timerTextField.setVisible(true);
        }
    }
    
    // event handler for textField for oven timer (when user enter "30" minutes, the next event occurs)
    public void processTextField(ActionEvent event) {
        int time = Integer.parseInt(timerTextField.getText());
        if (event.getSource() == timerTextField) {
            if (time == 30) {
            getChildren().removeAll(filledPanView, panCircle, ovenCircle, openOvenView, step5, ovenTimer, timerTextField);
            step6a.setVisible(true);
            uncutBrownieView.setVisible(true);
            cutButton.setVisible(true);
            }
        }
    }
    
    //-------------------------------------------------------------------------------------------------------------------------
    // step 6 (event handler for button to display the cut brownies image)
    public void processButtonPress5(ActionEvent event) {
        if(event.getSource() == cutButton) {
            step6b.setVisible(true);
            cutBrownieView.setVisible(true);
            drizzleLabel.setVisible(true);
            getChildren().removeAll(uncutBrownieView, step6a, cutButton);
            }
    }
    
    public void processKeyType(KeyEvent event) {
        if(event.getSource() == cutBrownieView) {
             if (event.getCharacter().equals("d")) {  
                drizzleView.setVisible(true);
                sugarLabel.setVisible(true);
                
                getChildren().removeAll(drizzleLabel, cutBrownieView);
                }
                 }
        }

    public void processKeyType2(KeyEvent event) {
        if(event.getSource() == drizzleView) {
             if (event.getCharacter().equals("p")) {  
                toppedView.setVisible(true);
                serveButton.setVisible(true);
                
                getChildren().removeAll(sugarLabel, drizzleView);
                }
                 }
        }
   
    //-------------------------------------------------------------------------------------------------------------------------
    // event handler for serving button
    public void processButtonPress8(ActionEvent event) {
        if(event.getSource() == serveButton) {
            finalBrownieView.setVisible(true);
            doneLabel.setVisible(true);
            getChildren().removeAll(toppedView, serveButton, step6b);
            }
    }
    
}
