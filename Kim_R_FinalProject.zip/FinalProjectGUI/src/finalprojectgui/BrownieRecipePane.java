package finalprojectgui;

import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

/**
 *
 * @author rebekahkim
 */
public class BrownieRecipePane extends FlowPane {
    private Label bLabel;
    private Label ingredients;
    private CheckBox butter;
    private CheckBox sugar;
    private CheckBox eggs;
    private CheckBox vanilla;
    private CheckBox cocoa;
    private CheckBox flour;
    private CheckBox chips;
    private Label instructions;
    private CheckBox step1;
    private CheckBox step2;
    private CheckBox step3;
    private CheckBox step4;
    private CheckBox step5;
    private CheckBox step6;
    private CheckBox step7;
    private Image brownieImage;
    private ImageView brownieImageView;
    private Label spacer;
    private Label spacer2;

    public BrownieRecipePane() {
        // recipe label
        bLabel = new Label("Brownie Recipe");
        Font brownieFont = Font.font("Courier New", FontWeight.BOLD, 26);       
        bLabel.setFont(brownieFont);
        bLabel.setTextFill(Color.DARKSEAGREEN);
        bLabel.setPrefWidth(400);                   
        bLabel.setWrapText(true);  
        
        //-------------------------------------------------------------------------------------------------------------------------
        // ingredients labels
        ingredients = new Label("Ingredients:");
        Font headingFont = Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20);       
        ingredients.setFont(headingFont);
        ingredients.setTextFill(Color.DARKSEAGREEN);
        ingredients.setPrefWidth(400);                   
        ingredients.setWrapText(true);  
        
        butter = new CheckBox("1 cup melted butter");
        Font ingredientFont = Font.font("Helvetica", FontWeight.BOLD, 16);       
        butter.setFont(ingredientFont);
        butter.setTextFill(Color.DARKSLATEGRAY);
        butter.setPrefWidth(400);                   
        butter.setWrapText(true);
        
        sugar = new CheckBox("2 cups granulated sugar");     
        sugar.setFont(ingredientFont);
        sugar.setTextFill(Color.DARKSLATEGRAY);
        sugar.setPrefWidth(400);                   
        sugar.setWrapText(true);
        
        eggs = new CheckBox("4 large eggs");      
        eggs.setFont(ingredientFont);
        eggs.setTextFill(Color.DARKSLATEGRAY);
        eggs.setPrefWidth(400);                   
        eggs.setWrapText(true);
        
        vanilla = new CheckBox("1 drop vanilla");      
        vanilla.setFont(ingredientFont);
        vanilla.setTextFill(Color.DARKSLATEGRAY);
        vanilla.setPrefWidth(400);                   
        vanilla.setWrapText(true);
        
        cocoa = new CheckBox("1 cup cocoa powder");      
        cocoa.setFont(ingredientFont);
        cocoa.setTextFill(Color.DARKSLATEGRAY);
        cocoa.setPrefWidth(400);                   
        cocoa.setWrapText(true);
        
        flour = new CheckBox("1 cup all-purpose flour");      
        flour.setFont(ingredientFont);
        flour.setTextFill(Color.DARKSLATEGRAY);
        flour.setPrefWidth(400);                   
        flour.setWrapText(true);
        
        chips = new CheckBox("1 cup chocolate chips");      
        chips.setFont(ingredientFont);
        chips.setTextFill(Color.DARKSLATEGRAY);
        chips.setPrefWidth(400);                   
        chips.setWrapText(true);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // instructions labels
        instructions = new Label("Instructions:");   
        instructions.setFont(headingFont);
        instructions.setTextFill(Color.DARKSEAGREEN);
        instructions.setPrefWidth(400);                   
        instructions.setWrapText(true);  
        
        step1 = new CheckBox("1. Preheat oven to 350 degrees.");      
        step1.setFont(ingredientFont);
        step1.setTextFill(Color.DARKSLATEGRAY);
        step1.setPrefWidth(400);                   
        step1.setWrapText(true);
        
        step2 = new CheckBox("2. In a mixing bowl, whisk butter, sugar, eggs, and vanilla extract until smooth.");      
        step2.setFont(ingredientFont);
        step2.setTextFill(Color.DARKSLATEGRAY);
        step2.setPrefWidth(400);                   
        step2.setWrapText(true);
        
        step3 = new CheckBox("3. Add flour, cocoa powder, and chocolate chips to the mixture.");      
        step3.setFont(ingredientFont);
        step3.setTextFill(Color.DARKSLATEGRAY);
        step3.setPrefWidth(400);                   
        step3.setWrapText(true);
        
        step4 = new CheckBox("4. Spread mixture into the square pan.");      
        step4.setFont(ingredientFont);
        step4.setTextFill(Color.DARKSLATEGRAY);
        step4.setPrefWidth(400);                   
        step4.setWrapText(true);
        
        step5 = new CheckBox("5. Bake in the oven for 30 minutes.");      
        step5.setFont(ingredientFont);
        step5.setTextFill(Color.DARKSLATEGRAY);
        step5.setPrefWidth(400);                   
        step5.setWrapText(true);
        
        step6 = new CheckBox("6. Remove from oven and cut into squares.");      
        step6.setFont(ingredientFont);
        step6.setTextFill(Color.DARKSLATEGRAY);
        step6.setPrefWidth(400);                   
        step6.setWrapText(true);
        
        step7 = new CheckBox("7. Decorate with caramel and powdered sugar.");      
        step7.setFont(ingredientFont);
        step7.setTextFill(Color.DARKSLATEGRAY);
        step7.setPrefWidth(400);                   
        step7.setWrapText(true);
        
        getChildren().addAll(bLabel, ingredients, butter, sugar, eggs, vanilla, 
                cocoa, flour, chips, instructions, step1, step2, step3, step4, 
                step5, step6, step7);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // image display
        spacer = new Label("");
        spacer.setPrefWidth(400);
        getChildren().add(spacer);
        
        spacer2 = new Label("");
        spacer2.setPrefWidth(100);
        getChildren().add(spacer2);
        
        brownieImage = new Image("file:brownie.jpg");
        brownieImageView = new ImageView(brownieImage);
        brownieImageView.setPreserveRatio(true);                                                              // keep width and height ratio the same
        brownieImageView.setFitWidth(200);  
        getChildren().add(brownieImageView);
        
    }
    
    
}
