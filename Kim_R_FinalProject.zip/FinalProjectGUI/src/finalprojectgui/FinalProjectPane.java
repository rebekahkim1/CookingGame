package finalprojectgui;

import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 *
 * @author rebekahkim
 */
public class FinalProjectPane extends Pane {
    
    private Label profileLabel;
    private Label titleLabel;
    private FinalProject intro;
    private Label introNameLabel;
    private TextField nameField;
    private Label ageLabel;
    private TextField ageField;
    private Label nameLabel;
    private Label zodiacLabel;
    private TextField zodiacField;
    private Label toBegin;
    private Button brownieButton;
    private Button crollButton;
    private Button matchaButton;
    private Scene bScene;
    private Image myImage1;
    private Image myImage2;
    private Image myImage3;
    private ImageView brownieImage;
    private ImageView crollImage;
    private ImageView matchaImage;
    private Image lemonImage;
    private ImageView lemonView;
    private Image orangeImage;
    private ImageView orangeView;
    private Image rollImage;
    private ImageView rollView;
    private Image pizzaImage;
    private ImageView pizzaView;
    private Image avocadoImage;
    private ImageView avocadoView;
    private Button avatarButton;
    

    public FinalProjectPane() {
    }

    public FinalProjectPane(FinalProject intro) {
        this.intro = intro;
        
        // profile labels
        profileLabel = new Label("The Baker's Profile: ");   
        Font profileFont = Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 34);       
        profileLabel.setFont(profileFont);
        profileLabel.setTextFill(Color.DARKSALMON);
        profileLabel.setPrefWidth(1200);                   
        profileLabel.setWrapText(true);
        profileLabel.setLayoutX(10);                                                                           // change location of image on the window
        profileLabel.setLayoutY(10);
        getChildren().add(profileLabel);
        
        titleLabel = new Label(intro.toString());    
        Font titleFont = Font.font("Courier New", 28);
        titleLabel.setFont(titleFont);
        titleLabel.setTextFill(Color.DARKSALMON);
        titleLabel.setPrefWidth(1200);                   
        titleLabel.setWrapText(true);          
        titleLabel.setLayoutX(10);                                                                           
        titleLabel.setLayoutY(50);        
        getChildren().add(titleLabel);
        
        nameField = new TextField(intro.getUsername());  
        nameField.setOnAction(this::processNameReturn);
        nameField.setLayoutX(110);                                                                           
        nameField.setLayoutY(170);
        nameLabel = new Label("Insert Name Here:");
        Font nameLabelFont = Font.font("Arial Narrow", FontWeight.BOLD, 14);   
        nameLabel.setFont(nameLabelFont);
        nameLabel.setTextFill(Color.LIGHTPINK);
        nameLabel.setWrapText(true);
        nameLabel.setLayoutX(10);                                                                           
        nameLabel.setLayoutY(170);      
        getChildren().addAll(nameLabel, nameField);
        
        ageField = new TextField("" + intro.getAge());  
        ageField.setOnAction(this::processAgeReturn);
        ageField.setLayoutX(400);                                                                           
        ageField.setLayoutY(170);
        ageLabel = new Label("Insert Age Here:");
        ageLabel.setFont(nameLabelFont);
        ageLabel.setTextFill(Color.LIGHTPINK);
        ageLabel.setWrapText(true);
        ageLabel.setLayoutX(305);                                                                           
        ageLabel.setLayoutY(170);   
        getChildren().addAll(ageLabel, ageField);
        
        zodiacField = new TextField(intro.getZodiac());  
        zodiacField.setOnAction(this::processZodiacReturn);
        zodiacField.setLayoutX(735);                                                                           
        zodiacField.setLayoutY(170);
        zodiacLabel = new Label("Insert Zodiac Sign Here:");
        zodiacLabel.setFont(nameLabelFont);
        zodiacLabel.setTextFill(Color.LIGHTPINK);
        zodiacLabel.setWrapText(true);
        zodiacLabel.setLayoutX(600);                                                                           
        zodiacLabel.setLayoutY(170); 
        getChildren().addAll(zodiacLabel, zodiacField);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // labels to choose the game
        toBegin = new Label("To begin, select the item would would like to create:");
        Font labelFont = Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20);  
        toBegin.setFont(labelFont);
        toBegin.setTextFill(Color.DARKSEAGREEN);
        toBegin.setPrefWidth(1200);                  
        toBegin.setWrapText(true);  
        toBegin.setLayoutX(10);                                                                           
        toBegin.setLayoutY(250); 
        getChildren().add(toBegin);
        
        // buttons for each game
        brownieButton = new Button("Fudge Brownies");   
        Font labelFont2 = Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 24);       
        brownieButton.setFont(labelFont2);
        brownieButton.setTextFill(Color.ROSYBROWN);
        brownieButton.setPrefWidth(370);                   
        brownieButton.setWrapText(true);   
        brownieButton.setLayoutX(10); 
        brownieButton.setLayoutY(280);
        
        crollButton = new Button("Cinnamon Rolls");       
        crollButton.setFont(labelFont2);
        crollButton.setTextFill(Color.ROSYBROWN);
        crollButton.setPrefWidth(400);                   
        crollButton.setWrapText(true);   
        crollButton.setLayoutX(380); 
        crollButton.setLayoutY(280);
        
        matchaButton = new Button("Iced Matcha Latte");       
        matchaButton.setFont(labelFont2);
        matchaButton.setTextFill(Color.ROSYBROWN);
        matchaButton.setPrefWidth(400);                   
        matchaButton.setWrapText(true);     
        matchaButton.setLayoutX(780);        
        matchaButton.setLayoutY(280);
        
        getChildren().addAll(brownieButton, crollButton, matchaButton);
        
        brownieButton.setOnAction(this::processButtonPress);
        crollButton.setOnAction(this::processButtonPress);
        matchaButton.setOnAction(this::processButtonPress);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // images for each game
        
        // add brownie image
        myImage1 = new Image("file:brownie.jpg");
        brownieImage = new ImageView(myImage1);
        brownieImage.setPreserveRatio(true);                                                              // keep width and height ratio the same
        brownieImage.setFitHeight(400);                                                                 
        brownieImage.setX(50);                                                                           // change location of image on the window
        brownieImage.setY(326);
        getChildren().add(brownieImage);

        // add cinnamon roll image
        myImage2 = new Image("file:cinnamonroll.jpg");
        crollImage = new ImageView(myImage2);
        crollImage.setPreserveRatio(true);                                                             
        crollImage.setFitHeight(400);                                                                  
        crollImage.setX(410);                                                                   
        crollImage.setY(325);
        getChildren().add(crollImage);
        
        // add matcha latte image
        myImage3 = new Image("file:matchalatte.jpeg");
        matchaImage = new ImageView(myImage3);
        matchaImage.setPreserveRatio(true);                                                              
        matchaImage.setFitHeight(400);                                                                 
        matchaImage.setX(820);                                                                           
        matchaImage.setY(325);
        getChildren().add(matchaImage);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // avatar images for each game
        
        lemonImage = new Image("file:lemon.PNG");
        lemonView = new ImageView(lemonImage);
        lemonView.setPreserveRatio(true);                                                              
        lemonView.setFitWidth(300);                                                                 
        lemonView.setX(900);                                                                           
        lemonView.setY(-17);
        lemonView.setVisible(false);
        
        orangeImage = new Image("file:orange.PNG");
        orangeView = new ImageView(orangeImage);
        orangeView.setPreserveRatio(true);                                                              
        orangeView.setFitWidth(300);                                                                 
        orangeView.setX(900);                                                                           
        orangeView.setY(-20);
        orangeView.setVisible(false);
        
        pizzaImage = new Image("file:pizza.PNG");
        pizzaView = new ImageView(pizzaImage);
        pizzaView.setPreserveRatio(true);                                                              
        pizzaView.setFitWidth(300);                                                                 
        pizzaView.setX(900);                                                                           
        pizzaView.setY(-25);
        pizzaView.setVisible(false);
        
        avocadoImage = new Image("file:avocado.PNG");
        avocadoView = new ImageView(avocadoImage);
        avocadoView.setPreserveRatio(true);                                                              
        avocadoView.setFitWidth(300);                                                                 
        avocadoView.setX(900);                                                                           
        avocadoView.setY(-25);
        avocadoView.setVisible(false);
        
        rollImage = new Image("file:cienna.PNG");
        rollView = new ImageView(rollImage);
        rollView.setPreserveRatio(true);                                                              
        rollView.setFitWidth(300);                                                                 
        rollView.setX(900);                                                                           
        rollView.setY(-40);
        rollView.setVisible(false);
        
        avatarButton = new Button("Click here to generate your avatar");      
        Font buttonFont = Font.font("Arial", 14);
        avatarButton.setFont(buttonFont);
        avatarButton.setTextFill(Color.DARKSALMON);
        avatarButton.setPrefWidth(250);                   
        avatarButton.setWrapText(true);          
        avatarButton.setLayoutX(650);                                                                           
        avatarButton.setLayoutY(5);        
        getChildren().add(avatarButton);
        
        avatarButton.setOnAction(this::processAvatarImage);
    }
    
    // action event to return name entered to the label
    public void processNameReturn(ActionEvent event) {
        intro.setUsername(nameField.getText());  
        titleLabel.setText(intro.toString());
        // System.out.println(nameField.getText());  
    }
    
    // action event to return age entered to the label
    public void processAgeReturn(ActionEvent event) {
        // use Integer.parseInt to interpret the text in the TextField as an integer
        int age = Integer.parseInt(ageField.getText());
        intro.setAge(age);
        titleLabel.setText(intro.toString());
    }
    
    // action event to return age entered to the label
    public void processZodiacReturn(ActionEvent event) {
        intro.setZodiac(zodiacField.getText());  
        titleLabel.setText(intro.toString());
    }
    
    // event handler for each button pressed
    public void processButtonPress(ActionEvent event) {
        if(event.getSource() == brownieButton) {
            Stage brownieWindow = new Stage();  
            BrowniePane bPane = new BrowniePane();
            VBox brownie = new VBox();  
            brownie.getChildren().add(bPane); 
            brownie.setStyle("-fx-background-color: #fff5ee");
            Scene bScene = new Scene(brownie, 1200, 800);
            brownieWindow.setScene(bScene);
            brownieWindow.setTitle("Fudge Brownies");
            brownieWindow.show();
            }
        else if(event.getSource() == crollButton) {
            Stage cRollWindow = new Stage(); 
            cRollPane cPane = new cRollPane();
            VBox cRoll = new VBox();  
            cRoll.getChildren().add(cPane); 
            cRoll.setStyle("-fx-background-color: #f0f8ff");
            Scene cScene = new Scene(cRoll, 1200, 800);
            cRollWindow.setScene(cScene);
            cRollWindow.setTitle("Cinnamon Rolls");
            cRollWindow.show();
        }    
        else if(event.getSource() == matchaButton) {
            Stage matchaWindow = new Stage(); 
            MatchaPane mPane = new MatchaPane();
            VBox matcha = new VBox();  
            matcha.getChildren().add(mPane); 
            matcha.setStyle("-fx-background-color: #F5FFFA");
            Scene mScene = new Scene(matcha, 1200, 800);
            matchaWindow.setScene(mScene);
            matchaWindow.setTitle("Iced Matcha Latte");
            matchaWindow.show();
        }
    }
   
    // action event to return avatar images based on the age inputted
    public void processAvatarImage(ActionEvent event) { 
        if(intro.getAge() < 10) {
            getChildren().add(rollView);
            rollView.setVisible(true);
            getChildren().removeAll(lemonView, pizzaView, avocadoView, orangeView);
        }
        else if(intro.getAge() < 20 && intro.getAge() >= 10) {
            getChildren().add(lemonView);
            lemonView.setVisible(true);
            getChildren().removeAll(rollView, pizzaView, avocadoView, orangeView);
        }
        else if(intro.getAge() < 30 && intro.getAge() >= 20) {
            getChildren().add(pizzaView);
            pizzaView.setVisible(true);
            getChildren().removeAll(lemonView, rollView, avocadoView, orangeView);
        }
        else if(intro.getAge() < 40 && intro.getAge() >= 30) {
            getChildren().add(avocadoView);
            avocadoView.setVisible(true);
            getChildren().removeAll(lemonView, pizzaView, rollView, orangeView);
        }
        else if(intro.getAge() >= 40) {
            getChildren().add(orangeView);
            orangeView.setVisible(true);
            getChildren().removeAll(lemonView, pizzaView, avocadoView, rollView);
        }
    }
   
}
