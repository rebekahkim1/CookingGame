package finalprojectgui;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;

/**
 *
 * @author rebekahkim
 */
public class ImagePane extends Pane {
    
    // attributes
    private Image myImage1;
    private Image myImage2;
    private Image myImage3;
    private ImageView brownieImage;
    private ImageView crollImage;
    private ImageView matchaImage;

    public ImagePane() {
        // add brownie image
        myImage1 = new Image("file:brownie.jpg");
        brownieImage = new ImageView(myImage1);
        brownieImage.setPreserveRatio(true);                                                              // keep width and height ratio the same
        brownieImage.setFitHeight(400);                                                                 
        brownieImage.setX(50);                                                                           // change location of image on the window
        brownieImage.setY(0);
        getChildren().add(brownieImage);

        // add cinnamon roll image
        myImage2 = new Image("file:cinnamonroll.jpg");
        crollImage = new ImageView(myImage2);
        crollImage.setPreserveRatio(true);                                                             
        crollImage.setFitHeight(400);                                                                  
        crollImage.setX(410);                                                                   
        crollImage.setY(0);
        getChildren().add(crollImage);
        
        // add matcha latte image
        myImage3 = new Image("file:matchalatte.jpeg");
        matchaImage = new ImageView(myImage3);
        matchaImage.setPreserveRatio(true);                                                              // keep width and height ratio the same
        matchaImage.setFitHeight(400);                                                                 
        matchaImage.setX(820);                                                                           // change location of image on the window
        matchaImage.setY(0);
        getChildren().add(matchaImage);
    }
    
}
