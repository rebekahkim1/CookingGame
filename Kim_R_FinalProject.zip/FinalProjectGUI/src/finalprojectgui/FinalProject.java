package finalprojectgui;

/**
 *
 * @author rebekahkim
 */
public class FinalProject {
    
    // attributes
    private String username;
    private Integer age;
    private String zodiac;
    private Double temperature;
    private Integer timer;
    
    // constructors
    
    public FinalProject() {  
    }
    
    public FinalProject(String username, Integer age, String zodiac) {  
        this.username = username;
        this.age = age;
        this.zodiac = zodiac;
    }

    public String toString() {
        String output;
        
        output = "Baking with " + username + "!" + "\n" +
                "Age: " + age + "\n" +
                "Zodiac Sign: " + zodiac + "\n";
        
        return output;
    }

    // getters and setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getZodiac() {
        return zodiac;
    }

    public void setZodiac(String zodiac) {
        this.zodiac = zodiac;
    }

    public Double getTemperature() {
        return temperature;
    }

    public void setTemperature(Double temperature) {
        this.temperature = temperature;
    }

    public Integer getTimer() {
        return timer;
    }

    public void setTimer(Integer timer) {
        this.timer = timer;
    }
    
    
    
}
