package finalprojectgui;

import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Shape;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 *
 * @author rebekahkim
 */
public class MatchaPane extends Pane {
    private Button RecipeButton;
    private Image waterImage;
    private ImageView waterView;
    private Image iceCubesImage;
    private ImageView iceCubesView;
    private Image matchaImage;
    private ImageView matchaView;
    private Image milkImage;
    private ImageView milkView;
    private Image syrupImage;
    private ImageView syrupView;
    private Image emptyCupImage;
    private ImageView emptyCupView;
    private Image emptyBowlImage;
    private ImageView emptyBowlView;
    private Image waterBowlImage;
    private ImageView waterBowlView;
    private Image syrupBowlImage;
    private ImageView syrupBowlView;
    private Image matchaBowlImage;
    private ImageView matchaBowlView;
    private Image iceCupImage;
    private ImageView iceCupView;
    private Image milkCupImage;
    private ImageView milkCupView;
    private Image matchaWhiskImage;
    private ImageView matchaWhiskView;
    private Image mixedBowlImage;
    private ImageView mixedBowlView;
    private Image mixingCupImage;
    private ImageView mixingCupView;
    private Image mixedCupImage;
    private ImageView mixedCupView;
    private Image matchaMilkCupImage;
    private ImageView matchaMilkCupView;
    private Image finalMatchaImage;
    private ImageView finalMatchaView;
    private Image waterImage2;
    private ImageView waterView2;
    private Image iceCubesImage2;
    private ImageView iceCubesView2;
    private Image matchaImage2;
    private ImageView matchaView2;
    private Image milkImage2;
    private ImageView milkView2;
    private Image syrupImage2;
    private ImageView syrupView2;
    private Label step1;
    private Label step2;
    private Label step3;
    private Label step4;
    private Label step5;
    private Label measureLabel;
    private Label measureWater;
    private Label measureSyrup;
    private Label measureMatcha;
    private Label measureIce;
    private Label measureMilk;
    private CheckBox icecube;
    private CheckBox water;
    private CheckBox matcha;
    private CheckBox milk;
    private CheckBox syrup;
    private Circle whiskCircle;
    private Circle bowlCircle;
    private Button serveButton;
    private Label doneLabel;
    private Button step2Button;

    public MatchaPane() {
        // Recipe Button that displays the window for the recipe
        RecipeButton = new Button("Click here for the Matcha Latte Recipe");   
        Font labelFont2 = Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20);       
        RecipeButton.setFont(labelFont2);
        RecipeButton.setTextFill(Color.ROSYBROWN);
        RecipeButton.setPrefWidth(1200);                   
        RecipeButton.setWrapText(true); 
        getChildren().add(RecipeButton);

        RecipeButton.setOnAction(this::processButtonPress);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // step 1
        
        step1 = new Label("Step 1: Choose the ingredients needed for step 1 in the Matcha Latte Recipe.");
        Font matchaFont = Font.font("Courier New", FontWeight.BOLD, 24);  
        step1.setFont(matchaFont);
        step1.setTextFill(Color.DARKSEAGREEN);
        step1.setPrefWidth(1200);                   
        step1.setWrapText(true); 
        step1.setLayoutY(50);
        getChildren().add(step1);
        
        // ingredients & checkboxes
        
        icecube = new CheckBox("Ice Cubes");
        Font ingredientFont = Font.font("Helvetica", FontWeight.BOLD, 18);       
        icecube.setFont(ingredientFont);
        icecube.setTextFill(Color.DARKSLATEGRAY);
        icecube.setPrefWidth(120); 
        icecube.setLayoutY(100);
        icecube.setLayoutX(40);
        iceCubesImage = new Image("file:icecubes.png");
        iceCubesView = new ImageView(iceCubesImage);
        iceCubesView.setPreserveRatio(true);                                                             
        iceCubesView.setFitHeight(100); 
        iceCubesView.setLayoutY(140);
        iceCubesView.setLayoutX(40);
        
        water = new CheckBox("Water");     
        water.setFont(ingredientFont);
        water.setTextFill(Color.DARKSLATEGRAY);
        water.setPrefWidth(200); 
        water.setLayoutY(100);
        water.setLayoutX(280);
        waterImage = new Image("file:water.png");
        waterView = new ImageView(waterImage);
        waterView.setPreserveRatio(true);                                                             
        waterView.setFitHeight(100); 
        waterView.setLayoutY(140);
        waterView.setLayoutX(280);
        
        matcha = new CheckBox("Matcha");     
        matcha.setFont(ingredientFont);
        matcha.setTextFill(Color.DARKSLATEGRAY);
        matcha.setPrefWidth(200); 
        matcha.setLayoutY(100);
        matcha.setLayoutX(520);
        matchaImage = new Image("file:matcha.png");
        matchaView = new ImageView(matchaImage);
        matchaView.setPreserveRatio(true);                                                             
        matchaView.setFitHeight(100); 
        matchaView.setLayoutY(140);
        matchaView.setLayoutX(520);
        
        milk = new CheckBox("Milk");     
        milk.setFont(ingredientFont);
        milk.setTextFill(Color.DARKSLATEGRAY);
        milk.setPrefWidth(200); 
        milk.setLayoutY(100);
        milk.setLayoutX(760);
        milkImage = new Image("file:milk.png");
        milkView = new ImageView(milkImage);
        milkView.setPreserveRatio(true);                                                             
        milkView.setFitHeight(100); 
        milkView.setLayoutY(140);
        milkView.setLayoutX(760);
        
        syrup = new CheckBox("Syrup");     
        syrup.setFont(ingredientFont);
        syrup.setTextFill(Color.DARKSLATEGRAY);
        syrup.setPrefWidth(200); 
        syrup.setLayoutY(100);
        syrup.setLayoutX(1000);
        syrupImage = new Image("file:syrup.png");
        syrupView = new ImageView(syrupImage);
        syrupView.setPreserveRatio(true);                                                             
        syrupView.setFitHeight(100); 
        syrupView.setLayoutY(140);
        syrupView.setLayoutX(1000);
        
        getChildren().addAll(icecube, iceCubesView, water, waterView, matcha, matchaView,
                milk, milkView, syrup, syrupView);
        
        matcha.setOnAction(this::processCheckBoxes);
        water.setOnAction(this::processCheckBoxes);
        syrup.setOnAction(this::processCheckBoxes);
        
        milk.setOnAction(this::processCheckBoxes2);
        icecube.setOnAction(this::processCheckBoxes2);
        
        // measuring labels and images
        
        measureLabel = new Label("Click each ingredient according to how much the recipe calls for:");    
        measureLabel.setFont(matchaFont);
        measureLabel.setTextFill(Color.DARKSEAGREEN);
        measureLabel.setPrefWidth(1200);     
        measureLabel.setLayoutY(50);
        measureLabel.setWrapText(true); 
        measureLabel.setVisible(false);
        
        emptyBowlImage = new Image("file:emptyBowlM.png");
        emptyBowlView = new ImageView(emptyBowlImage);
        emptyBowlView.setPreserveRatio(true);                                                             
        emptyBowlView.setFitHeight(400); 
        emptyBowlView.setLayoutY(300);
        emptyBowlView.setLayoutX(300);
        emptyBowlView.setVisible(false);
        
        measureWater = new Label("Click the # of Tablespoons Needed:");
        measureWater.setFont(ingredientFont);
        measureWater.setTextFill(Color.DARKBLUE);
        measureWater.setPrefWidth(1200); 
        measureWater.setLayoutY(90);
        measureWater.setVisible(false);
        
        waterImage2 = new Image("file:water.png");
        waterView2 = new ImageView(waterImage2);
        waterView2.setPreserveRatio(true);                                                             
        waterView2.setFitHeight(200); 
        waterView2.setLayoutY(130);
        waterView2.setLayoutX(620);
        waterView2.setRotate(-140);
        waterView2.setVisible(false);
        
        waterBowlImage = new Image("file:waterBowl.png");
        waterBowlView = new ImageView(waterBowlImage);
        waterBowlView.setPreserveRatio(true);                                                             
        waterBowlView.setFitHeight(400); 
        waterBowlView.setLayoutY(300);
        waterBowlView.setLayoutX(300);
        waterBowlView.setVisible(false);
        
        waterView2.setOnMouseClicked(this::processMouseClick);
        
        measureSyrup = new Label("Click the # of Tablespoons Needed:");
        measureSyrup.setFont(ingredientFont);
        measureSyrup.setTextFill(Color.DARKBLUE);
        measureSyrup.setPrefWidth(1200); 
        measureSyrup.setLayoutY(90);
        measureSyrup.setVisible(false);
        
        syrupImage2 = new Image("file:syrup.png");
        syrupView2 = new ImageView(syrupImage2);
        syrupView2.setPreserveRatio(true);                                                             
        syrupView2.setFitHeight(200); 
        syrupView2.setLayoutY(130);
        syrupView2.setLayoutX(620);
        syrupView2.setRotate(-140);
        syrupView2.setVisible(false);
        
        syrupBowlImage = new Image("file:syrupBowl.png");
        syrupBowlView = new ImageView(syrupBowlImage);
        syrupBowlView.setPreserveRatio(true);                                                             
        syrupBowlView.setFitHeight(400); 
        syrupBowlView.setLayoutY(300);
        syrupBowlView.setLayoutX(300);
        syrupBowlView.setVisible(false);
        
        syrupView2.setOnMouseClicked(this::processMouseClick2);
        
        measureMatcha = new Label("Click the # of Tablespoons Needed:");
        measureMatcha.setFont(ingredientFont);
        measureMatcha.setTextFill(Color.DARKBLUE);
        measureMatcha.setPrefWidth(1200); 
        measureMatcha.setLayoutY(90);
        measureMatcha.setVisible(false);
        
        matchaImage2 = new Image("file:matcha.png");
        matchaView2 = new ImageView(matchaImage2);
        matchaView2.setPreserveRatio(true);                                                             
        matchaView2.setFitHeight(200); 
        matchaView2.setLayoutY(130);
        matchaView2.setLayoutX(620);
        matchaView2.setRotate(-140);
        matchaView2.setVisible(false);
        
        matchaBowlImage = new Image("file:matchaBowl.png");
        matchaBowlView = new ImageView(matchaBowlImage);
        matchaBowlView.setPreserveRatio(true);                                                             
        matchaBowlView.setFitHeight(400); 
        matchaBowlView.setLayoutY(300);
        matchaBowlView.setLayoutX(300);
        matchaBowlView.setVisible(false);
        
        matchaView2.setOnMouseClicked(this::processMouseClick3);
        
        
        getChildren().addAll(emptyBowlView, measureLabel, measureWater, waterView2, waterBowlView, 
                measureSyrup, syrupView2, syrupBowlView, measureMatcha, matchaView2, 
                matchaBowlView);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // step 2
        
        step2 = new Label("Step 2: Whisk together by dragging the match whisk to the bowl."); 
        step2.setFont(matchaFont);
        step2.setTextFill(Color.DARKSEAGREEN);
        step2.setPrefWidth(1200);                   
        step2.setWrapText(true); 
        step2.setLayoutY(50);
        step2.setVisible(false);
        getChildren().add(step2);
        
        matchaWhiskImage = new Image("file:matchawhisk.png");
        matchaWhiskView = new ImageView(matchaWhiskImage);
        matchaWhiskView.setPreserveRatio(true);                                                             
        matchaWhiskView.setFitHeight(200);  
        matchaWhiskView.setLayoutY(300);
        matchaWhiskView.setLayoutX(70);
        matchaWhiskView.setVisible(false);
        //matchaWhiskView.setRotate(180);
        getChildren().add(matchaWhiskView);
        
        matchaWhiskView.setOnMouseDragged(this::processMouseDrag);
        
        whiskCircle = new Circle(230, 300, 50);
        whiskCircle.setFill(Color.TRANSPARENT);
        whiskCircle.setStroke(Color.TRANSPARENT);
        whiskCircle.setVisible(false);
        
        bowlCircle = new Circle(590, 500, 50);
        bowlCircle.setFill(Color.TRANSPARENT);
        bowlCircle.setStroke(Color.TRANSPARENT);
        bowlCircle.setVisible(false);
        getChildren().addAll(whiskCircle, bowlCircle);
        
        mixedBowlImage = new Image("file:mixedMatchaBowl.png");
        mixedBowlView = new ImageView(mixedBowlImage);
        mixedBowlView.setPreserveRatio(true);                                                             
        mixedBowlView.setFitHeight(400);  
        mixedBowlView.setLayoutY(300);
        mixedBowlView.setLayoutX(300);
        mixedBowlView.setVisible(false);
        getChildren().add(mixedBowlView);
        
        step2Button = new Button("Click here for Step 3");       
        step2Button.setFont(labelFont2);
        step2Button.setTextFill(Color.CADETBLUE);
        step2Button.setPrefWidth(300);                   
        step2Button.setWrapText(true); 
        step2Button.setLayoutX(450);
        step2Button.setLayoutY(150);
        step2Button.setVisible(false);
        getChildren().add(step2Button);
        
        step2Button.setOnAction(this::processButtonPress2);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // step 3
        
        step3 = new Label("Step 3: Choose the ingredients needed for step 3 in the Matcha Latte Recipe."); 
        step3.setFont(matchaFont);
        step3.setTextFill(Color.DARKSEAGREEN);
        step3.setPrefWidth(1200);                   
        step3.setWrapText(true); 
        step3.setLayoutY(50);
        step3.setVisible(false);
        getChildren().add(step3);
        
        emptyCupImage = new Image("file:emptyCup.png");
        emptyCupView = new ImageView(emptyCupImage);
        emptyCupView.setPreserveRatio(true);                                                             
        emptyCupView.setFitHeight(400); 
        emptyCupView.setLayoutY(300);
        emptyCupView.setLayoutX(300);
        emptyCupView.setVisible(false);
        
        measureIce = new Label("Click the # of 1/2 Cups Needed:");
        measureIce.setFont(ingredientFont);
        measureIce.setTextFill(Color.DARKBLUE);
        measureIce.setPrefWidth(1200); 
        measureIce.setLayoutY(90);
        measureIce.setVisible(false);
        
        iceCubesImage2 = new Image("file:icecubes.png");
        iceCubesView2 = new ImageView(iceCubesImage2);
        iceCubesView2.setPreserveRatio(true);                                                             
        iceCubesView2.setFitHeight(200); 
        iceCubesView2.setLayoutY(130);
        iceCubesView2.setLayoutX(620);
        iceCubesView2.setRotate(-140);
        iceCubesView2.setVisible(false);
        
        iceCubesView2.setOnMouseClicked(this::processMouseClick4);
        
        iceCupImage = new Image("file:iceCup.png");
        iceCupView = new ImageView(iceCupImage);
        iceCupView.setPreserveRatio(true);                                                             
        iceCupView.setFitHeight(400); 
        iceCupView.setLayoutY(300);
        iceCupView.setLayoutX(300);
        iceCupView.setVisible(false);
        
        iceCubesView2.setOnMouseClicked(this::processMouseClick4);
        
        measureMilk = new Label("Click the # of Cups Needed:");
        measureMilk.setFont(ingredientFont);
        measureMilk.setTextFill(Color.DARKBLUE);
        measureMilk.setPrefWidth(1200); 
        measureMilk.setLayoutY(90);
        measureMilk.setVisible(false);
        
        milkImage2 = new Image("file:milk.png");
        milkView2 = new ImageView(milkImage2);
        milkView2.setPreserveRatio(true);                                                             
        milkView2.setFitHeight(200); 
        milkView2.setLayoutY(130);
        milkView2.setLayoutX(620);
        milkView2.setRotate(-140);
        milkView2.setVisible(false);
        
        milkView2.setOnMouseClicked(this::processMouseClick5);
        
        milkCupImage = new Image("file:milkCup.png");
        milkCupView = new ImageView(milkCupImage);
        milkCupView.setPreserveRatio(true);                                                             
        milkCupView.setFitHeight(400); 
        milkCupView.setLayoutY(300);
        milkCupView.setLayoutX(300);
        milkCupView.setVisible(false);
        
        getChildren().addAll(emptyCupView, measureIce, iceCubesView2, iceCupView, measureMilk, milkView2, milkCupView);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // step 4
        
        step4 = new Label("Step 4: Pour matcha mixture by clicking on the bowl 7 times."); 
        step4.setFont(matchaFont);
        step4.setTextFill(Color.DARKSEAGREEN);
        step4.setPrefWidth(1200);                   
        step4.setWrapText(true); 
        step4.setLayoutY(50);
        step4.setVisible(false);
        getChildren().add(step4);
        
        mixedBowlView.setOnMouseClicked(this::processMouseRotate);
        
        matchaMilkCupImage = new Image("file:matchaMilkCup.png");
        matchaMilkCupView = new ImageView(matchaMilkCupImage);
        matchaMilkCupView.setPreserveRatio(true);                                                             
        matchaMilkCupView.setFitHeight(400); 
        matchaMilkCupView.setLayoutY(300);
        matchaMilkCupView.setLayoutX(300);
        matchaMilkCupView.setVisible(false);
        getChildren().add(matchaMilkCupView);
        //matchaMilkCupView.setOnMouseClicked(this::processMouseClick6);
        matchaMilkCupView.setFocusTraversable(true);  
        matchaMilkCupView.setOnKeyTyped(this::processKeyType);  
        
        //-------------------------------------------------------------------------------------------------------------------------
        // step 5
        
        step5 = new Label("Step 5: Mix together by hitting the 'tab' key and then 's' for shake twice."); 
        step5.setFont(matchaFont);
        step5.setTextFill(Color.DARKSEAGREEN);
        step5.setPrefWidth(1200);                   
        step5.setWrapText(true); 
        step5.setLayoutY(50);
        step5.setVisible(false);
        getChildren().add(step5);
        
        mixingCupImage = new Image("file:mixingCup.png");
        mixingCupView = new ImageView(mixingCupImage);
        mixingCupView.setPreserveRatio(true);  
        mixingCupView.setFitHeight(400); 
        mixingCupView.setLayoutY(300);
        mixingCupView.setLayoutX(300);
        mixingCupView.setVisible(false);
        //mixingCupView.setOnMouseClicked(this::processMouseClick7);
        mixingCupView.setFocusTraversable(true);  
        mixingCupView.setOnKeyTyped(this::processKeyType2);  
        
        mixedCupImage = new Image("file:mixedCup.png");
        mixedCupView = new ImageView(mixedCupImage);
        mixedCupView.setPreserveRatio(true);
        mixedCupView.setFitHeight(400); 
        mixedCupView.setLayoutY(300);
        mixedCupView.setLayoutX(300);
        mixedCupView.setVisible(false);
        
        getChildren().addAll(mixingCupView, mixedCupView);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // final serve
        
        serveButton = new Button("Click here to finish!");       
        serveButton.setFont(labelFont2);
        serveButton.setTextFill(Color.CADETBLUE);
        serveButton.setPrefWidth(300);                   
        serveButton.setWrapText(true); 
        serveButton.setLayoutX(450);
        serveButton.setLayoutY(150);
        serveButton.setVisible(false);
        getChildren().add(serveButton);
        
        serveButton.setOnAction(this::processButtonPressFinal);
        
        doneLabel = new Label("All Done!");
        Font doneFont = new Font("Noteworthy Light", 32);
        doneLabel.setFont(doneFont);
        doneLabel.setTextFill(Color.DEEPPINK);
        doneLabel.setPrefWidth(1200);                   
        doneLabel.setWrapText(true); 
        doneLabel.setVisible(false);
        doneLabel.setLayoutY(100);
        doneLabel.setLayoutX(550);
        getChildren().add(doneLabel);
        
        finalMatchaImage = new Image("file:finalMatcha.png");
        finalMatchaView = new ImageView(finalMatchaImage);
        finalMatchaView.setPreserveRatio(true);                                                             
        finalMatchaView.setFitHeight(150); 
        finalMatchaView.setFitHeight(400); 
        finalMatchaView.setLayoutY(300);
        finalMatchaView.setLayoutX(300);
        finalMatchaView.setVisible(false);
        
        getChildren().add(finalMatchaView);
    }
    
    // event handler for displaying recipe window when button is pressed
    public void processButtonPress(ActionEvent event) {
        if(event.getSource() == RecipeButton) {
            Stage recipeWindow = new Stage();  
            MatchaRecipePane mRecipePane = new MatchaRecipePane();
            VBox mRecipe = new VBox();  
            mRecipe.getChildren().add(mRecipePane); 
            mRecipe.setStyle("-fx-background-color: #f0fff0");
            Scene bScene = new Scene(mRecipe, 400, 700);
            recipeWindow.setScene(bScene);
            recipeWindow.setTitle("Iced Matcha Latte Recipe");
            recipeWindow.show();
            }
            
        }
    
    //-------------------------------------------------------------------------------------------------------------------------
    // step 1 checkboxes event handler
    
    public void processCheckBoxes(ActionEvent event) {
            if(water.isSelected() && syrup.isSelected() && matcha.isSelected()){
                    measureLabel.setVisible(true);
                    measureWater.setVisible(true);
                    waterView2.setVisible(true);
                    emptyBowlView.setVisible(true);
                    
                    getChildren().removeAll(step1, icecube, iceCubesView, water, waterView, matcha, matchaView,
                    milk, milkView, syrup, syrupView);
                }    
    }
    
    // event handlers for measruring the ingredients with clicks
    public void processMouseClick(MouseEvent event) {
        if(event.getClickCount() == 2 && event.getSource() == waterView2) {
            measureSyrup.setVisible(true);
            syrupView2.setVisible(true);
            waterBowlView.setVisible(true);
            
            getChildren().removeAll(waterView2, measureWater, emptyBowlView);
        }
    }
    
    public void processMouseClick2(MouseEvent event) {
        if(event.getClickCount() == 1 && event.getSource() == syrupView2) {
            measureMatcha.setVisible(true);
            matchaView2.setVisible(true);
            syrupBowlView.setVisible(true);
            
            getChildren().removeAll(syrupView2, measureSyrup, waterBowlView);
        }
    }
    
    public void processMouseClick3(MouseEvent event) {
        if(event.getClickCount() == 1 && event.getSource() == matchaView2) {
            step2.setVisible(true);
            matchaBowlView.setVisible(true);
            matchaWhiskView.setVisible(true);
            whiskCircle.setVisible(true);
            bowlCircle.setVisible(true);
            
            getChildren().removeAll(matchaView2, measureMatcha, measureLabel, syrupBowlView);
        }
    }
    
    //-------------------------------------------------------------------------------------------------------------------------
    // step 2
    // event handler for dragging the whisk image and circle to the bowl image and circle
    public void processMouseDrag(MouseEvent event) {
        if (event.getSource() == matchaWhiskView) { 
            double newX = event.getSceneX();
            double newY = event.getSceneY();
            matchaWhiskView.setLayoutX(newX);
            matchaWhiskView.setLayoutY(newY);
            whiskCircle.setCenterX(newX + 100);
            whiskCircle.setCenterY(newY + 150);
        }
        if (Shape.intersect(bowlCircle, whiskCircle).getBoundsInLocal().isEmpty() == false) {
            mixedBowlView.setVisible(true);
            step2Button.setVisible(true);
            
            getChildren().removeAll(step2, matchaWhiskView, whiskCircle, bowlCircle, matchaBowlView);
        }
    }
    
    // event handler for step 2 button
    public void processButtonPress2(ActionEvent event) {
        if(event.getSource() == step2Button) {
            step3.setVisible(true);
            getChildren().addAll(icecube, iceCubesView, water, waterView, matcha, matchaView,
                                 milk, milkView, syrup, syrupView);
                    icecube.setVisible(true);
                    iceCubesView.setVisible(true);
                    water.setVisible(true);
                    waterView.setVisible(true);
                    matcha.setVisible(true);
                    matchaView.setVisible(true);
                    milk.setVisible(true);
                    milkView.setVisible(true);
                    syrup.setVisible(true);
                    syrupView.setVisible(true);
            getChildren().removeAll(step2Button, mixedBowlView);
        }
    }
    
    //-------------------------------------------------------------------------------------------------------------------------
    // step 3 ingredients
    
    // event handler for checkboxes for ingredients
    public void processCheckBoxes2(ActionEvent event) {
            if(icecube.isSelected() && milk.isSelected()){   
                emptyCupView.setVisible(true);
                measureIce.setVisible(true);
                iceCubesView2.setVisible(true);
                    
                getChildren().removeAll(icecube, iceCubesView, water, waterView, matcha, matchaView,
                                        milk, milkView, syrup, syrupView);
                }    
    }
    
    // event handler for clicking on the ingredients to measure them
    public void processMouseClick4(MouseEvent event) {
        if(event.getSource() == iceCubesView2) {
            iceCupView.setVisible(true);
            measureMilk.setVisible(true);
            milkView2.setVisible(true);
            
            getChildren().removeAll(iceCubesView2, measureIce, emptyCupView);
        }
    }
    
    public void processMouseClick5(MouseEvent event) {
        if(event.getClickCount() == 2 && event.getSource() == milkView2) {
            milkCupView.setVisible(true);
            step4.setVisible(true);
            getChildren().add(mixedBowlView);
            mixedBowlView.setVisible(true);
            mixedBowlView.setFitHeight(200);
            mixedBowlView.setLayoutX(650);
            mixedBowlView.setLayoutY(150);
            
            getChildren().removeAll(measureLabel, milkView2, measureMilk, iceCupView, step3);
        }
    }
    
    //-------------------------------------------------------------------------------------------------------------------------
    // step 4
    
    // event handler for rotating bowl by clicking on it
    public void processMouseRotate(MouseEvent event) {
        if (event.getSource() == mixedBowlView) {  
                mixedBowlView.setRotate(mixedBowlView.getRotate() - 5);  
            if (event.getClickCount() == 7) {
                step5.setVisible(true);
                matchaMilkCupView.setVisible(true);
                
                getChildren().removeAll(mixedBowlView, step4);
            }
        }
    }
    
    //-------------------------------------------------------------------------------------------------------------------------
    // step 5
    
    // event handler for typing the s key
    public void processKeyType(KeyEvent event) {
        if(event.getSource() == matchaMilkCupView) {
            if (event.getCharacter().equals("s")) {  
                mixingCupView.setVisible(true);
            
                getChildren().removeAll(matchaMilkCupView);
            }
        }
    }
    
    public void processKeyType2(KeyEvent event) {
        if(event.getSource() == mixingCupView) {
            if (event.getCharacter().equals("s")) {  
                mixedCupView.setVisible(true);
                serveButton.setVisible(true);
            
                getChildren().removeAll(mixingCupView);
            }
        }
    }
    
    //-------------------------------------------------------------------------------------------------------------------------
    // final
    
    // event handler for final button
    public void processButtonPressFinal(ActionEvent event) {
        if(event.getSource() == serveButton) {
            finalMatchaView.setVisible(true);
            doneLabel.setVisible(true);
            
            getChildren().removeAll(serveButton, mixedCupView, serveButton, step5);
            }
    }
}
