package finalprojectgui;

import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

/**
 *
 * @author rebekahkim
 */
public class MatchaRecipePane extends FlowPane {
    private Label mLabel;
    private Label ingredients;
    private CheckBox icecube;
    private CheckBox water;
    private CheckBox matcha;
    private CheckBox milk;
    private CheckBox syrup;
    private Label instructions;
    private CheckBox step1;
    private CheckBox step2;
    private CheckBox step3;
    private CheckBox step4;
    private CheckBox step5;
    private Image matchaImage;
    private ImageView matchaImageView;
    private Label spacer;
    private Label spacer2;

    public MatchaRecipePane() {
        // recipe label
        mLabel = new Label("Matcha Latte Recipe");
        Font matchaFont = Font.font("Courier New", FontWeight.BOLD, 26);       
        mLabel.setFont(matchaFont);
        mLabel.setTextFill(Color.DARKSEAGREEN);
        mLabel.setPrefWidth(400);                   
        mLabel.setWrapText(true);  
        
        //-------------------------------------------------------------------------------------------------------------------------
        // ingredients labels
        ingredients = new Label("Ingredients:");
        Font headingFont = Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20);       
        ingredients.setFont(headingFont);
        ingredients.setTextFill(Color.DARKSEAGREEN);
        ingredients.setPrefWidth(400);                   
        ingredients.setWrapText(true);  
        
        icecube = new CheckBox("1/2 cup of ice cubes");
        Font ingredientFont = Font.font("Helvetica", FontWeight.BOLD, 16);       
        icecube.setFont(ingredientFont);
        icecube.setTextFill(Color.DARKSLATEGRAY);
        icecube.setPrefWidth(400);                   
        icecube.setWrapText(true);
        
        water = new CheckBox("2 tablespoons of warm water");     
        water.setFont(ingredientFont);
        water.setTextFill(Color.DARKSLATEGRAY);
        water.setPrefWidth(400);                   
        water.setWrapText(true);
        
        syrup = new CheckBox("1 tablespoon of vanilla syrup");     
        syrup.setFont(ingredientFont);
        syrup.setTextFill(Color.DARKSLATEGRAY);
        syrup.setPrefWidth(400);                   
        syrup.setWrapText(true);
        
        matcha = new CheckBox("1 tablespoon of matcha powder");      
        matcha.setFont(ingredientFont);
        matcha.setTextFill(Color.DARKSLATEGRAY);
        matcha.setPrefWidth(400);                   
        matcha.setWrapText(true);
        
        milk = new CheckBox("2 cups of milk");      
        milk.setFont(ingredientFont);
        milk.setTextFill(Color.DARKSLATEGRAY);
        milk.setPrefWidth(400);                   
        milk.setWrapText(true);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // instructions labels
        instructions = new Label("Instructions:");   
        instructions.setFont(headingFont);
        instructions.setTextFill(Color.DARKSEAGREEN);
        instructions.setPrefWidth(400);                   
        instructions.setWrapText(true);  
        
        step1 = new CheckBox("1. Add water, vanilla syrup, and matcha powder to a bowl");      
        step1.setFont(ingredientFont);
        step1.setTextFill(Color.DARKSLATEGRAY);
        step1.setPrefWidth(400);                   
        step1.setWrapText(true);
        
        step2 = new CheckBox("2. Whisk together the ingredients in the bowl");      
        step2.setFont(ingredientFont);
        step2.setTextFill(Color.DARKSLATEGRAY);
        step2.setPrefWidth(400);                   
        step2.setWrapText(true);
        
        step3 = new CheckBox("3. Add ice and milk in a glass cup");      
        step3.setFont(ingredientFont);
        step3.setTextFill(Color.DARKSLATEGRAY);
        step3.setPrefWidth(400);                   
        step3.setWrapText(true);
        
        step4 = new CheckBox("4. Add matcha mixture in the cup with milk and ice");      
        step4.setFont(ingredientFont);
        step4.setTextFill(Color.DARKSLATEGRAY);
        step4.setPrefWidth(400);                   
        step4.setWrapText(true);
        
        step5 = new CheckBox("5. Mix together everything in the cup and serve");      
        step5.setFont(ingredientFont);
        step5.setTextFill(Color.DARKSLATEGRAY);
        step5.setPrefWidth(400);                   
        step5.setWrapText(true);
        
        getChildren().addAll(mLabel, ingredients, icecube, water, syrup, matcha, milk, 
                instructions, step1, step2, step3, step4, step5);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // image display
        spacer = new Label("");
        spacer.setPrefWidth(400);
        getChildren().add(spacer);
        
        spacer2 = new Label("");
        spacer2.setPrefWidth(100);
        getChildren().add(spacer2);
        
        matchaImage = new Image("file:matchalatte.jpeg");
        matchaImageView = new ImageView(matchaImage);
        matchaImageView.setPreserveRatio(true);                                                              
        matchaImageView.setFitWidth(200); 
        getChildren().add(matchaImageView);
    }
    
    
    
}
