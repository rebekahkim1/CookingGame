package finalprojectgui;

import javafx.scene.layout.Pane;
import java.text.DecimalFormat;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Shape;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 *
 * @author rebekahkim
 */
public class cRollPane extends Pane {
    private Button cRecipeButton;
    private Label step1;
    private Slider ovenTempSlider;
    private Double temp;
    private Label ovenTempLabel;
    private Label step2;
    private CheckBox dough;
    private Image doughImage;
    private ImageView doughView;
    private CheckBox cinSug;
    private Image cinSugImage;
    private ImageView cinSugView;
    private CheckBox butter;
    private Image butterImage;
    private ImageView butterView;
    private CheckBox frosting;
    private Image frostingImage;
    private ImageView frostingView;
    private Label step3;
    private Image onOvenImage;
    private ImageView onOvenView;
    private Image doughImage1;
    private ImageView doughView1;
    private Image doughImage2;
    private ImageView doughView2;
    private Image doughImage3;
    private ImageView doughView3;
    private Image doughImage4;
    private ImageView doughView4;
    private Image doughImage5;
    private ImageView doughView5;
    private Image doughImage6;
    private ImageView doughView6;
    private Image doughImage7;
    private ImageView doughView7;
    private Image doughImage8;
    private ImageView doughView8;
    private Label step2a;
    private Label measureLabel;
    private Label measureCinSugLabel;
    private Label measureButterLabel;
    private Image cinSugImage2;
    private ImageView cinSugView2;
    private Image butterImage2;
    private ImageView butterView2;
    private Image bowlCinSugImage;
    private ImageView bowlCinSugView;
    private Image bowlButterImage;
    private ImageView bowlButterView;
    private Image mixedBowlImage;
    private ImageView mixedBowlView;
    private Label step3b;
    private Circle bowlCircle;
    private Circle whiskCircle;
    private Image whiskImage;
    private ImageView whiskView;
    private Button step4Button;
    private Image cinSugDoughImage;
    private ImageView cinSugDoughView;
    private Label step5;
    private Image rollDoughImage;
    private ImageView rollDoughView;
    private Image rollImage;
    private ImageView rollView;
    private Label step6;
    private Button cutButton;
    private Image rollImage2;
    private ImageView rollView2;
    private Image rollImage3;
    private ImageView rollView3;
    private Image openOvenImage;
    private ImageView openOvenView;
    private Image uncookedImage;
    private ImageView uncookedView;
    private Circle ovenCircle;
    private Circle panCircle;
    private Label ovenTimer;
    private TextField timerTextField;
    private Label step6a;
    private Label step7;
    private Image cookedImage;
    private ImageView cookedView;
    private Image toppedImage;
    private ImageView toppedView;
    private Button serveButton;
    private Button closeButton;
    private Image finalImage;
    private ImageView finalView;
    private Label step4b;
    private Button step6Button;
    private Button step7Button;
    private Label doneLabel;
    private Image rollingPinImage;
    private ImageView rollingPinView;
    private Image rollingPinImage2;
    private ImageView rollingPinView2;
    private Image rollingPinImage3;
    private ImageView rollingPinView3;
    private Image rollingPinImage4;
    private ImageView rollingPinView4;
    private Image rollingPinImage5;
    private ImageView rollingPinView5;
    private Image rollingPinImage6;
    private ImageView rollingPinView6;
    private Image rollingPinImage7;
    private ImageView rollingPinView7;
    private Circle leftCircle;
    private Circle rightCircle;
    private Circle pinCircle;
    private Circle leftCircle2;
    private Circle rightCircle2;
    private Circle leftCircle3;
    private Circle rightCircle3;
    private Circle leftCircle4;
    private Circle rightCircle4;
    private Button step3Button;

    public cRollPane() {
        // Recipe Button that displays the window for the recipe
        cRecipeButton = new Button("Click here for the Cinnamon Roll Recipe");   
        Font labelFont2 = Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20);       
        cRecipeButton.setFont(labelFont2);
        cRecipeButton.setTextFill(Color.ROSYBROWN);
        cRecipeButton.setPrefWidth(1200);                   
        cRecipeButton.setWrapText(true); 
        getChildren().add(cRecipeButton);
        
        cRecipeButton.setOnAction(this::processButtonPress);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // step 1
        
        step1 = new Label("Step 1: Slide the temperature bar to preheat the oven.");
        Font brownieFont = Font.font("Courier New", FontWeight.BOLD, 24);       
        step1.setFont(brownieFont);
        step1.setTextFill(Color.DARKSEAGREEN);
        step1.setPrefWidth(1200);                   
        step1.setWrapText(true); 
        step1.setLayoutY(50);
        getChildren().add(step1);
        
        onOvenImage = new Image("file:onOven.png");
        onOvenView = new ImageView(onOvenImage);
        onOvenView.setPreserveRatio(true);                                                             
        onOvenView.setFitHeight(500);
        onOvenView.setLayoutY(200);
        onOvenView.setLayoutX(300);
        getChildren().add(onOvenView);
        
        temp = 0.0;
        ovenTempSlider = new Slider(0, 450, temp);
        SliderListener sliderListener = new SliderListener();  
        ovenTempSlider.valueProperty().addListener(sliderListener);
        ovenTempSlider.setPrefWidth(900);
        ovenTempLabel = new Label("Temperature: " + temp);
        Font sliderFont = Font.font("Arial Narrow", 20);   
        ovenTempLabel.setFont(sliderFont);
        ovenTempLabel.setLayoutY(100);
        ovenTempLabel.setLayoutX(20);
        ovenTempSlider.setLayoutY(100);
        ovenTempSlider.setLayoutX(150);
        getChildren().addAll(ovenTempLabel, ovenTempSlider);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // step 2 (checkboxes & ingredient image display)
        
        step2a = new Label("Step 2: Choose the ingredients needed for step 2 in the Cinnamon Roll Recipe.");
        step2a.setFont(brownieFont);
        step2a.setTextFill(Color.DARKSEAGREEN);
        step2a.setPrefWidth(1200);                   
        step2a.setWrapText(true); 
        step2a.setLayoutY(50);
        step2a.setVisible(false);
        getChildren().add(step2a);

        dough = new CheckBox("Dough");
        Font ingredientFont = Font.font("Helvetica", FontWeight.BOLD, 18);       
        dough.setFont(ingredientFont);
        dough.setTextFill(Color.DARKSLATEGRAY);
        dough.setPrefWidth(120); 
        dough.setLayoutY(100);
        dough.setLayoutX(50);
        doughImage = new Image("file:dough.png");
        doughView = new ImageView(doughImage);
        doughView.setPreserveRatio(true);                                                             
        doughView.setFitHeight(80); 
        doughView.setLayoutY(170);
        doughView.setLayoutX(50);
        dough.setVisible(false);
        doughView.setVisible(false);
        
        cinSug = new CheckBox("Cinnamon Sugar");     
        cinSug.setFont(ingredientFont);
        cinSug.setTextFill(Color.DARKSLATEGRAY);
        cinSug.setPrefWidth(200); 
        cinSug.setLayoutY(100);
        cinSug.setLayoutX(330);
        cinSugImage = new Image("file:cinnamonSugar.png");
        cinSugView = new ImageView(cinSugImage);
        cinSugView.setPreserveRatio(true);                                                             
        cinSugView.setFitHeight(100); 
        cinSugView.setLayoutY(160);
        cinSugView.setLayoutX(330);
        cinSug.setVisible(false);
        cinSugView.setVisible(false);
        
        butter = new CheckBox("Butter");    
        butter.setFont(ingredientFont);
        butter.setTextFill(Color.DARKSLATEGRAY);
        butter.setPrefWidth(120); 
        butter.setLayoutY(100);
        butter.setLayoutX(600);
        butterImage = new Image("file:butter.png");
        butterView = new ImageView(butterImage);
        butterView.setPreserveRatio(true);                                                             
        butterView.setFitHeight(130); 
        butterView.setLayoutY(130);
        butterView.setLayoutX(600);
        butter.setVisible(false);
        butterView.setVisible(false);
        
        frosting = new CheckBox("Cream Cheese Frosting");      
        frosting.setFont(ingredientFont);
        frosting.setTextFill(Color.DARKSLATEGRAY);
        frosting.setPrefWidth(250); 
        frosting.setLayoutY(100);
        frosting.setLayoutX(850);
        frostingImage = new Image("file:frosting.png");
        frostingView = new ImageView(frostingImage);
        frostingView.setPreserveRatio(true);                                                             
        frostingView.setFitHeight(150); 
        frostingView.setLayoutY(130);
        frostingView.setLayoutX(850);
        frosting.setVisible(false);
        frostingView.setVisible(false);
        
        getChildren().addAll(dough, doughView, cinSug, cinSugView, butter, butterView, frosting, frostingView);
        dough.setOnAction(this::processCheckBoxes);
        butter.setOnAction(this::processCheckBoxes2);
        cinSug.setOnAction(this::processCheckBoxes2);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // step 2 (rolling dough images)
        
        step2 = new Label("Roll dough by dragging the rolling pan from the right green circle to the left green circle.");   
        step2.setFont(brownieFont);
        step2.setTextFill(Color.DARKSEAGREEN);
        step2.setPrefWidth(1200);                   
        step2.setWrapText(true); 
        step2.setVisible(false);
        step2.setLayoutY(50);
        getChildren().add(step2);
        
        doughImage1 = new Image("file:dough1.png");
        doughView1 = new ImageView(doughImage1);
        doughView1.setPreserveRatio(true);                                                             
        doughView1.setFitHeight(500); 
        doughView1.setLayoutY(200);
        doughView1.setLayoutX(250);
        doughView1.setVisible(false);
        
        doughImage2 = new Image("file:dough2.png");
        doughView2 = new ImageView(doughImage2);
        doughView2.setPreserveRatio(true);                                                             
        doughView2.setFitHeight(500); 
        doughView2.setLayoutY(200);
        doughView2.setLayoutX(250);
        doughView2.setVisible(false);
        
        doughImage3 = new Image("file:dough3.png");
        doughView3 = new ImageView(doughImage3);
        doughView3.setPreserveRatio(true);                                                             
        doughView3.setFitHeight(500); 
        doughView3.setLayoutY(200);
        doughView3.setLayoutX(250);
        doughView3.setVisible(false);
        
        doughImage4 = new Image("file:dough4.png");
        doughView4 = new ImageView(doughImage4);
        doughView4.setPreserveRatio(true);                                                             
        doughView4.setFitHeight(500); 
        doughView4.setLayoutY(200);
        doughView4.setLayoutX(250);
        doughView4.setVisible(false);
       
        doughImage5 = new Image("file:dough5.png");
        doughView5 = new ImageView(doughImage5);
        doughView5.setPreserveRatio(true);                                                             
        doughView5.setFitHeight(500); 
        doughView5.setLayoutY(200);
        doughView5.setLayoutX(250);
        doughView5.setVisible(false);
        
        doughImage6 = new Image("file:dough6.png");
        doughView6 = new ImageView(doughImage6);
        doughView6.setPreserveRatio(true);                                                             
        doughView6.setFitHeight(500); 
        doughView6.setLayoutY(200);
        doughView6.setLayoutX(250);
        doughView6.setVisible(false);
        
        doughImage7 = new Image("file:dough7.png");
        doughView7 = new ImageView(doughImage7);
        doughView7.setPreserveRatio(true);                                                             
        doughView7.setFitHeight(500); 
        doughView7.setLayoutY(200);
        doughView7.setLayoutX(250);
        doughView7.setVisible(false);
        
        doughImage8 = new Image("file:dough7.png");
        doughView8 = new ImageView(doughImage8);
        doughView8.setPreserveRatio(true);                                                             
        doughView8.setFitHeight(500); 
        doughView8.setLayoutY(200);
        doughView8.setLayoutX(250);
        doughView8.setVisible(false);
        
        rollingPinImage = new Image("file:rollingPin.png");
        rollingPinView = new ImageView(rollingPinImage);
        rollingPinView.setPreserveRatio(true);                                                             
        rollingPinView.setFitHeight(500); 
        rollingPinView.setLayoutY(200);
        rollingPinView.setLayoutX(700);
        rollingPinView.setVisible(false);
        
        rollingPinImage2 = new Image("file:rollingPin.png");
        rollingPinView2 = new ImageView(rollingPinImage2);
        rollingPinView2.setPreserveRatio(true);                                                             
        rollingPinView2.setFitHeight(500); 
        rollingPinView2.setLayoutY(200);
        rollingPinView2.setLayoutX(900);
        rollingPinView2.setVisible(false);
        
        rollingPinImage3 = new Image("file:rollingPin.png");
        rollingPinView3 = new ImageView(rollingPinImage3);
        rollingPinView3.setPreserveRatio(true);                                                             
        rollingPinView3.setFitHeight(500); 
        rollingPinView3.setLayoutY(200);
        rollingPinView3.setLayoutX(300);
        rollingPinView3.setVisible(false);
        
        rollingPinImage4 = new Image("file:rollingPin.png");
        rollingPinView4 = new ImageView(rollingPinImage4);
        rollingPinView4.setPreserveRatio(true);                                                             
        rollingPinView4.setFitHeight(500); 
        rollingPinView4.setLayoutY(200);
        rollingPinView4.setLayoutX(900);
        rollingPinView4.setVisible(false);
        
        rollingPinImage5 = new Image("file:rollingPin.png");
        rollingPinView5 = new ImageView(rollingPinImage5);
        rollingPinView5.setPreserveRatio(true);                                                             
        rollingPinView5.setFitHeight(500); 
        rollingPinView5.setLayoutY(200);
        rollingPinView5.setLayoutX(300);
        rollingPinView5.setVisible(false);
        
        rollingPinImage6 = new Image("file:rollingPin.png");
        rollingPinView6 = new ImageView(rollingPinImage6);
        rollingPinView6.setPreserveRatio(true);                                                             
        rollingPinView6.setFitHeight(500); 
        rollingPinView6.setLayoutY(200);
        rollingPinView6.setLayoutX(900);
        rollingPinView6.setVisible(false);
        
        rollingPinImage7 = new Image("file:rollingPin.png");
        rollingPinView7 = new ImageView(rollingPinImage);
        rollingPinView7.setPreserveRatio(true);                                                             
        rollingPinView7.setFitHeight(500); 
        rollingPinView7.setLayoutY(200);
        rollingPinView7.setLayoutX(300);
        rollingPinView7.setVisible(false);
        
        rollingPinView.setOnMouseDragged(this::processMouseDrag3);
        rollingPinView2.setOnMouseDragged(this::processMouseDrag4);
        rollingPinView3.setOnMouseDragged(this::processMouseDrag5);
        rollingPinView4.setOnMouseDragged(this::processMouseDrag6);
        rollingPinView5.setOnMouseDragged(this::processMouseDrag7);
        rollingPinView6.setOnMouseDragged(this::processMouseDrag8);
        rollingPinView7.setOnMouseDragged(this::processMouseDrag9);
        
        pinCircle = new Circle(700, 450, 50);
        pinCircle.setFill(Color.TRANSPARENT);
        pinCircle.setStroke(Color.TRANSPARENT);
        pinCircle.setVisible(false);
        
        leftCircle = new Circle(300, 420, 25);
        leftCircle.setFill(Color.DARKSEAGREEN);
        leftCircle.setStroke(Color.DARKSEAGREEN);
        leftCircle.setVisible(false);
        
        rightCircle = new Circle(1000, 420, 25);
        rightCircle.setFill(Color.DARKSEAGREEN);
        rightCircle.setStroke(Color.DARKSEAGREEN);
        rightCircle.setVisible(false);
        
        leftCircle2 = new Circle(300, 420, 25);
        leftCircle2.setFill(Color.DARKSEAGREEN);
        leftCircle2.setStroke(Color.DARKSEAGREEN);
        leftCircle2.setVisible(false);
        
        rightCircle2 = new Circle(1000, 420, 25);
        rightCircle2.setFill(Color.DARKSEAGREEN);
        rightCircle2.setStroke(Color.DARKSEAGREEN);
        rightCircle2.setVisible(false);
        
        leftCircle3 = new Circle(300, 420, 25);
        leftCircle3.setFill(Color.DARKSEAGREEN);
        leftCircle3.setStroke(Color.DARKSEAGREEN);
        leftCircle3.setVisible(false);
        
        rightCircle3 = new Circle(1000, 420, 25);
        rightCircle3.setFill(Color.DARKSEAGREEN);
        rightCircle3.setStroke(Color.DARKSEAGREEN);
        rightCircle3.setVisible(false);
        
        leftCircle4 = new Circle(300, 420, 25);
        leftCircle4.setFill(Color.DARKSEAGREEN);
        leftCircle4.setStroke(Color.DARKSEAGREEN);
        leftCircle4.setVisible(false);
        
        rightCircle4 = new Circle(1000, 420, 25);
        rightCircle4.setFill(Color.DARKSEAGREEN);
        rightCircle4.setStroke(Color.DARKSEAGREEN);
        rightCircle4.setVisible(false);
        
        getChildren().addAll(doughView1, doughView2, doughView3, doughView4, doughView5, doughView6, doughView7, doughView8,
                rollingPinView, pinCircle, leftCircle, rightCircle);
        
        step3Button = new Button("Click here for Step 3");       
        step3Button.setFont(labelFont2);
        step3Button.setTextFill(Color.CADETBLUE);
        step3Button.setPrefWidth(400);                   
        step3Button.setWrapText(true); 
        step3Button.setLayoutX(400);
        step3Button.setLayoutY(150);
        step3Button.setVisible(false);
        getChildren().add(step3Button);
        step3Button.setOnAction(this::processButtonPress9);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // step 3
        
        step3 = new Label("Step 3: Select the ingredients needed for step 3 of the recipe.");   
        step3.setFont(brownieFont);
        step3.setTextFill(Color.DARKSEAGREEN);
        step3.setPrefWidth(1200);                   
        step3.setWrapText(true); 
        step3.setVisible(false);
        step3.setLayoutY(50);
        getChildren().add(step3);
       
        measureLabel = new Label("Click each ingredient according to how much the recipe calls for:");    
        measureLabel.setFont(brownieFont);
        measureLabel.setTextFill(Color.DARKSEAGREEN);
        measureLabel.setPrefWidth(1200);     
        measureLabel.setLayoutY(50);
        measureLabel.setWrapText(true); 
        measureLabel.setVisible(false);
        
        measureButterLabel = new Label("Click the # of 1/4 Cups Needed:");
        measureButterLabel.setFont(ingredientFont);
        measureButterLabel.setTextFill(Color.DARKBLUE);
        measureButterLabel.setPrefWidth(1200); 
        measureButterLabel.setLayoutY(90);
        butterImage2 = new Image("file:butter.png");
        butterView2 = new ImageView(butterImage2);
        butterView2.setPreserveRatio(true);                                                             
        butterView2.setFitHeight(150); 
        butterView2.setLayoutY(130);
        butterView2.setLayoutX(600);
        measureButterLabel.setVisible(false);
        butterView2.setVisible(false);
        
        measureCinSugLabel = new Label("Click the # of Cups Needed:");
        measureCinSugLabel.setFont(ingredientFont);
        measureCinSugLabel.setTextFill(Color.DARKBLUE);
        measureCinSugLabel.setPrefWidth(1200); 
        measureCinSugLabel.setLayoutY(90);
        cinSugImage2 = new Image("file:cinnamonSugar.png");
        cinSugView2 = new ImageView(cinSugImage2);
        cinSugView2.setPreserveRatio(true);                                                             
        cinSugView2.setFitHeight(150);     
        cinSugView2.setLayoutY(130);
        cinSugView2.setLayoutX(620);
        cinSugView2.setRotate(-140);
        measureCinSugLabel.setVisible(false);
        cinSugView2.setVisible(false);
        
        butterView2.setOnMouseClicked(this::processMouseClick);
        cinSugView2.setOnMouseClicked(this::processMouseClick2);
        
        getChildren().addAll(measureLabel, measureButterLabel, measureCinSugLabel, butterView2, cinSugView2);
        
        bowlButterImage = new Image("file:bowlButter.png");
        bowlButterView = new ImageView(bowlButterImage);
        bowlButterView.setPreserveRatio(true);                                                             
        bowlButterView.setFitHeight(400);  
        bowlButterView.setVisible(false);
        bowlButterView.setLayoutY(300);
        bowlButterView.setLayoutX(300);
        
        bowlCinSugImage = new Image("file:bowlCinSug.png");
        bowlCinSugView = new ImageView(bowlCinSugImage);
        bowlCinSugView.setPreserveRatio(true);                                                             
        bowlCinSugView.setFitHeight(400);  
        bowlCinSugView.setVisible(false);
        bowlCinSugView.setLayoutY(300);
        bowlCinSugView.setLayoutX(300);
       
        step3b = new Label("Mix the ingredients by dragging the whisk to the bowl.");
        step3b.setFont(brownieFont);
        step3b.setTextFill(Color.DARKSEAGREEN);
        step3b.setPrefWidth(1000);                   
        step3b.setWrapText(true); 
        step3b.setVisible(false);
        step3b.setLayoutY(50);
        getChildren().add(step3b);
        
        getChildren().addAll(bowlButterView, bowlCinSugView);
        
        bowlCircle = new Circle(550, 300, 50);
        bowlCircle.setFill(Color.TRANSPARENT);
        bowlCircle.setStroke(Color.TRANSPARENT);
        bowlCircle.setVisible(false);
        
        whiskCircle = new Circle(200, 250, 50);
        whiskCircle.setFill(Color.TRANSPARENT);
        whiskCircle.setStroke(Color.TRANSPARENT);
        whiskCircle.setVisible(false);
        
        whiskImage = new Image("file:whisk.png");
        whiskView = new ImageView(whiskImage);
        whiskView.setPreserveRatio(true);                                                             
        whiskView.setFitHeight(300);  
        whiskView.setLayoutY(120);
        whiskView.setLayoutX(100);
        whiskView.setVisible(false);
        
        getChildren().addAll(bowlCircle, whiskCircle, whiskView);
        
        whiskView.setOnMouseDragged(this::processMouseDrag);
        //setOnMouseDragReleased(this::processMouseRelease);
        
        mixedBowlImage = new Image("file:bowlMix.png");
        mixedBowlView = new ImageView(mixedBowlImage);
        mixedBowlView.setPreserveRatio(true);                                                             
        mixedBowlView.setFitHeight(400);  
        mixedBowlView.setLayoutY(300);
        mixedBowlView.setLayoutX(300);
        mixedBowlView.setVisible(false);
        getChildren().add(mixedBowlView);

        //-------------------------------------------------------------------------------------------------------------------------
        // step 4
        
        step4Button = new Button("Click here for Step 4");       
        step4Button.setFont(labelFont2);
        step4Button.setTextFill(Color.CADETBLUE);
        step4Button.setPrefWidth(400);                   
        step4Button.setWrapText(true); 
        step4Button.setLayoutX(400);
        step4Button.setLayoutY(150);
        step4Button.setVisible(false);
        getChildren().add(step4Button);
        
        step4Button.setOnAction(this::processButtonPress2);
        
        step4b = new Label("Click on the bowl to pour the Cinnamon Sugar and Butter Mixture onto the Dough");
        step4b.setFont(brownieFont);
        step4b.setTextFill(Color.DARKSEAGREEN);
        step4b.setPrefWidth(1200);                   
        step4b.setWrapText(true); 
        step4b.setVisible(false);
        step4b.setLayoutY(50);
        getChildren().add(step4b);
        
        cinSugDoughImage = new Image("file:cinSugDough.png");
        cinSugDoughView = new ImageView(cinSugDoughImage);
        cinSugDoughView.setPreserveRatio(true);                                                             
        cinSugDoughView.setFitHeight(450);  
        cinSugDoughView.setLayoutY(200);
        cinSugDoughView.setLayoutX(300);
        cinSugDoughView.setVisible(false);
        getChildren().add(cinSugDoughView);
        cinSugDoughView.setOnMouseClicked(this::processMouseClick12);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // step 5
        
        step5 = new Label("Step 5: Roll dough into a log shape by clicking on the dough.");
        step5.setFont(brownieFont);
        step5.setTextFill(Color.DARKSEAGREEN);
        step5.setPrefWidth(1200);                   
        step5.setWrapText(true); 
        step5.setVisible(false);
        step5.setLayoutY(50);
        getChildren().add(step5);
        
        mixedBowlView.setOnMouseClicked(this::processMouseRotate);
        
        rollDoughImage = new Image("file:rollDough.png");
        rollDoughView = new ImageView(rollDoughImage);
        rollDoughView.setPreserveRatio(true);                                                             
        rollDoughView.setFitHeight(450);  
        rollDoughView.setLayoutY(300);
        rollDoughView.setLayoutX(300);
        rollDoughView.setVisible(false);
        getChildren().add(rollDoughView);
        
        rollDoughView.setOnMouseClicked(this::processMouseClick11);
        
        rollImage = new Image("file:roll.PNG");
        rollView = new ImageView(rollImage);
        rollView.setPreserveRatio(true);                                                             
        rollView.setFitHeight(450);  
        rollView.setLayoutY(300);
        rollView.setLayoutX(300);
        rollView.setVisible(false);
        getChildren().add(rollView);
        
        step6Button = new Button("Click here for Step 6");       
        step6Button.setFont(labelFont2);
        step6Button.setTextFill(Color.CADETBLUE);
        step6Button.setPrefWidth(300);                   
        step6Button.setWrapText(true); 
        step6Button.setLayoutX(430);
        step6Button.setLayoutY(150);
        step6Button.setVisible(false);
        getChildren().add(step6Button);
        step6Button.setOnAction(this::processButtonPress4);
                
        //-------------------------------------------------------------------------------------------------------------------------
        // step 6
        
        step6 = new Label("Step 6: Cut the dough.");
        step6.setFont(brownieFont);
        step6.setTextFill(Color.DARKSEAGREEN);
        step6.setPrefWidth(1200);                   
        step6.setWrapText(true); 
        step6.setVisible(false);
        step6.setLayoutY(50);
        getChildren().add(step6);
        
        cutButton = new Button("Click here to cut Cinnamon Rolls");       
        cutButton.setFont(labelFont2);
        cutButton.setTextFill(Color.CADETBLUE);
        cutButton.setPrefWidth(500);                   
        cutButton.setWrapText(true); 
        cutButton.setLayoutX(350);
        cutButton.setLayoutY(150);
        cutButton.setVisible(false);
        getChildren().add(cutButton);
        
        cutButton.setOnAction(this::processButtonPress5);
        
        rollImage2 = new Image("file:roll2.PNG");
        rollView2 = new ImageView(rollImage2);
        rollView2.setPreserveRatio(true);                                                             
        rollView2.setFitHeight(450);  
        rollView2.setLayoutY(300);
        rollView2.setLayoutX(300);
        rollView2.setVisible(false);
        getChildren().add(rollView2);
        
        rollImage3 = new Image("file:roll3.PNG");
        rollView3 = new ImageView(rollImage3);
        rollView3.setPreserveRatio(true);                                                             
        rollView3.setFitHeight(450);  
        rollView3.setLayoutY(300);
        rollView3.setLayoutX(300);
        rollView3.setVisible(false);
        getChildren().add(rollView3);
        
        step7Button = new Button("Click here for Step 7");       
        step7Button.setFont(labelFont2);
        step7Button.setTextFill(Color.CADETBLUE);
        step7Button.setPrefWidth(300);                   
        step7Button.setWrapText(true); 
        step7Button.setLayoutX(450);
        step7Button.setLayoutY(150);
        step7Button.setVisible(false);
        getChildren().add(step7Button);
        step7Button.setOnAction(this::processButtonPress6);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // step 7
        
        step6a = new Label("Step 7: Place the cut Cinnamon Rolls into the oven.");
        step6a.setFont(brownieFont);
        step6a.setTextFill(Color.DARKSEAGREEN);
        step6a.setPrefWidth(1200);                   
        step6a.setWrapText(true); 
        step6a.setVisible(false);
        step6a.setLayoutY(50);
        getChildren().add(step6a);
        
        openOvenImage = new Image("file:openOven.jpeg");
        openOvenView = new ImageView(openOvenImage);
        openOvenView.setPreserveRatio(true);                                                             
        openOvenView.setFitHeight(600);  
        openOvenView.setLayoutY(100);
        openOvenView.setLayoutX(300);
        openOvenView.setVisible(false);
        openOvenView.toBack();
        getChildren().add(openOvenView);
        
        uncookedImage = new Image("file:uncooked.png");
        uncookedView = new ImageView(uncookedImage);
        uncookedView.setPreserveRatio(true);                                                             
        uncookedView.setFitHeight(150);  
        uncookedView.setVisible(false);
        uncookedView.toFront();
        getChildren().add(uncookedView);
        
        uncookedView.setOnMouseDragged(this::processMouseDrag2);
        
        panCircle = new Circle(200, 610, 50);
        panCircle.setFill(Color.TRANSPARENT);
        panCircle.setStroke(Color.TRANSPARENT);
        panCircle.setVisible(false);
        
        ovenCircle = new Circle(600, 400, 50);
        ovenCircle.setFill(Color.TRANSPARENT);
        ovenCircle.setStroke(Color.TRANSPARENT);
        ovenCircle.setVisible(false);
        
        getChildren().addAll(panCircle, ovenCircle);
        
        ovenTimer = new Label("Oven Timer (type number of minutes)");
        ovenTimer.setFont(brownieFont);
        ovenTimer.setTextFill(Color.DEEPPINK);
        ovenTimer.setPrefWidth(1200);                   
        ovenTimer.setWrapText(true); 
        ovenTimer.setVisible(false);
        ovenTimer.setLayoutY(100);
        ovenTimer.setLayoutX(50);
        getChildren().add(ovenTimer);
        
        timerTextField = new TextField("");
        timerTextField.setFont(brownieFont);
        timerTextField.setPrefWidth(200);     
        timerTextField.setVisible(false);
        timerTextField.setLayoutY(130);
        timerTextField.setLayoutX(50);
        getChildren().add(timerTextField);
        
        timerTextField.setOnAction(this::processTextField);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // step 8
        
        step7 = new Label("Step 8: Cover the cinnamon rolls with frosting by hitting the 'tab' key and then 'f'.");
        step7.setFont(brownieFont);
        step7.setTextFill(Color.DARKSEAGREEN);
        step7.setPrefWidth(1200);                   
        step7.setWrapText(true); 
        step7.setVisible(false);
        step7.setLayoutY(50);
        getChildren().add(step7);
        
        cookedImage = new Image("file:cooked.png");
        cookedView = new ImageView(cookedImage);
        cookedView.setPreserveRatio(true);                                                             
        cookedView.setFitHeight(400);  
        cookedView.setLayoutY(300);
        cookedView.setLayoutX(300);
        cookedView.setVisible(false);
        getChildren().add(cookedView);
        cookedView.setFocusTraversable(true);
        cookedView.setOnKeyTyped(this::processKeyType);  
        
        /*
        frostingButton = new Button("Click here to add Cream Cheese Frosting");       
        frostingButton.setFont(labelFont2);
        frostingButton.setTextFill(Color.CADETBLUE);
        frostingButton.setPrefWidth(500);                   
        frostingButton.setWrapText(true); 
        frostingButton.setLayoutX(350);
        frostingButton.setLayoutY(150);
        frostingButton.setVisible(false);
        getChildren().add(frostingButton);
        
        frostingButton.setOnAction(this::processButtonPress7);
*/
        
        toppedImage = new Image("file:icingRolls.png");
        toppedView = new ImageView(toppedImage);
        toppedView.setPreserveRatio(true);                                                             
        toppedView.setFitHeight(400);  
        toppedView.setLayoutY(300);
        toppedView.setLayoutX(300);
        toppedView.setVisible(false);
        getChildren().add(toppedView);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // final serving
        
        serveButton = new Button("Click here to finish!");       
        serveButton.setFont(labelFont2);
        serveButton.setTextFill(Color.CADETBLUE);
        serveButton.setPrefWidth(300);                   
        serveButton.setWrapText(true); 
        serveButton.setLayoutX(450);
        serveButton.setLayoutY(150);
        serveButton.setVisible(false);
        getChildren().add(serveButton);
        
        serveButton.setOnAction(this::processButtonPress8);
        
        finalImage = new Image("file:rollFinal.PNG");
        finalView = new ImageView(finalImage);
        finalView.setPreserveRatio(true);                                                             
        finalView.setFitHeight(400);  
        finalView.setLayoutY(300);
        finalView.setLayoutX(300);
        finalView.setVisible(false);
        getChildren().add(finalView);
        
        doneLabel = new Label("All Done!");
        Font doneFont = new Font("Noteworthy Light", 32);
        doneLabel.setFont(doneFont);
        doneLabel.setTextFill(Color.DEEPPINK);
        doneLabel.setPrefWidth(1200);                   
        doneLabel.setWrapText(true); 
        doneLabel.setVisible(false);
        doneLabel.setLayoutY(100);
        doneLabel.setLayoutX(550);
        getChildren().add(doneLabel);
        
        closeButton = new Button("Close this Window");       
        closeButton.setFont(labelFont2);
        closeButton.setTextFill(Color.CADETBLUE);
        closeButton.setPrefWidth(300);                   
        closeButton.setWrapText(true); 
        closeButton.setLayoutX(500);
        closeButton.setLayoutY(600);
        closeButton.setVisible(false);
        getChildren().add(closeButton);
        //closeButton.setOnAction(actionEvent -> Platform.exit());
        
        //closeButton.setOnAction(this::processButtonPress9);
    }
    
    // event handler for displaying recipe window when button is pressed
    public void processButtonPress(ActionEvent event) {
        if(event.getSource() == cRecipeButton) {
            Stage recipeWindow = new Stage();  
            cRollRecipePane cRecipePane = new cRollRecipePane();
            VBox cRecipe = new VBox();  
            cRecipe.getChildren().add(cRecipePane); 
            cRecipe.setStyle("-fx-background-color: #f0fff0");
            Scene cScene = new Scene(cRecipe, 400, 700);
            recipeWindow.setScene(cScene);
            recipeWindow.setTitle("Cinnamon Roll Recipe");
            recipeWindow.show();
            }
            
        }
    
    //-------------------------------------------------------------------------------------------------------------------------
    // step 1 (event listener for oven slider)
    
    private class SliderListener implements ChangeListener<Number> {

            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                temp = ovenTempSlider.getValue();  
                DecimalFormat fmt = new DecimalFormat("0"); 
                ovenTempLabel.setText("Temperature: " + fmt.format(temp));

                ovenTempSlider.setMajorTickUnit(50);  
                ovenTempSlider.setMinorTickCount(25);  
                ovenTempSlider.setShowTickMarks(true);  
                ovenTempSlider.setShowTickLabels(true);
                
                if(temp > 399.5 && temp < 400.5) {
                    step2a.setVisible(true);
                    dough.setVisible(true);
                    doughView.setVisible(true);
                    butter.setVisible(true);
                    butterView.setVisible(true);
                    cinSug.setVisible(true);
                    cinSugView.setVisible(true);
                    frosting.setVisible(true);
                    frostingView.setVisible(true);
                    
                    getChildren().removeAll(step1, onOvenView, ovenTempLabel, ovenTempSlider);
                }
            }
    }

    //-------------------------------------------------------------------------------------------------------------------------
    // step 2 (event handler for check box)
    
    public void processCheckBoxes(ActionEvent event) {
            if(dough.isSelected()){
                    step2.setVisible(true);
                    doughView1.setVisible(true);
                    rollingPinView.setVisible(true);
                    pinCircle.setVisible(true);
                    leftCircle.setVisible(true);
                    rightCircle.setVisible(true);
                    
                    getChildren().removeAll(step2a, dough, doughView, butter,
                    butterView, cinSug, cinSugView, frosting, frostingView);
                }    
    }
    
    // event handlers for rolling the dough
    
    public void processMouseDrag3(MouseEvent event) {
        if (event.getSource() == rollingPinView) { 
            double newX = event.getX();
            double newY = event.getY();
            rollingPinView.setX(newX);
            rollingPinView.setY(newY);
            pinCircle.setCenterX(newX + 650);
            pinCircle.setCenterY(newY + 400);
        }
        if (Shape.intersect(pinCircle, rightCircle).getBoundsInLocal().isEmpty() == false) {
            getChildren().add(rollingPinView2);
            doughView2.setVisible(true);
            rollingPinView2.setVisible(true);
            
            getChildren().removeAll(doughView1, rollingPinView);
        }
    }
            
    public void processMouseDrag4(MouseEvent event) {
        if (event.getSource() == rollingPinView2) { 
            double newX = event.getX();
            double newY = event.getY();
            rollingPinView2.setX(newX);
            rollingPinView2.setY(newY);
            pinCircle.setCenterX(newX + 950);
            pinCircle.setCenterY(newY + 400);
        }
        if (Shape.intersect(pinCircle, leftCircle).getBoundsInLocal().isEmpty() == false) {
            getChildren().addAll(rightCircle2, rollingPinView3);
            doughView3.setVisible(true);
            rightCircle2.setVisible(true);
            rollingPinView3.setVisible(true);
            
            getChildren().removeAll(doughView2, rightCircle, rollingPinView2);
        }
    }
    
    public void processMouseDrag5(MouseEvent event) {
        if (event.getSource() == rollingPinView3) { 
            double newX = event.getX();
            double newY = event.getY();
            rollingPinView3.setX(newX);
            rollingPinView3.setY(newY);
            pinCircle.setCenterX(newX + 450);
            pinCircle.setCenterY(newY + 400);
        }
        if (Shape.intersect(pinCircle, rightCircle2).getBoundsInLocal().isEmpty() == false) {
            getChildren().addAll(leftCircle2, rollingPinView4);
            doughView4.setVisible(true);
            leftCircle2.setVisible(true);
            rollingPinView4.setVisible(true);
            
            getChildren().removeAll(doughView3, leftCircle, rollingPinView3);
        }
    }
    
    public void processMouseDrag6(MouseEvent event) {
        if (event.getSource() == rollingPinView4) { 
            double newX = event.getX();
            double newY = event.getY();
            rollingPinView4.setX(newX);
            rollingPinView4.setY(newY);
            pinCircle.setCenterX(newX + 950);
            pinCircle.setCenterY(newY + 400);
        }
        if (Shape.intersect(pinCircle, leftCircle2).getBoundsInLocal().isEmpty() == false) {
            getChildren().addAll(rightCircle3, rollingPinView5);
            doughView5.setVisible(true);
            rightCircle3.setVisible(true);
            rollingPinView5.setVisible(true);
            
            getChildren().removeAll(doughView4, rightCircle2, rollingPinView4);
        }
    }
    
    public void processMouseDrag7(MouseEvent event) {
        if (event.getSource() == rollingPinView5) { 
            double newX = event.getX();
            double newY = event.getY();
            rollingPinView5.setX(newX);
            rollingPinView5.setY(newY);
            pinCircle.setCenterX(newX + 450);
            pinCircle.setCenterY(newY + 400);
        }
        if (Shape.intersect(pinCircle, rightCircle3).getBoundsInLocal().isEmpty() == false) {
            getChildren().addAll(leftCircle3, rollingPinView6);
            doughView6.setVisible(true);
            leftCircle3.setVisible(true);
            rollingPinView6.setVisible(true);
            
            getChildren().removeAll(doughView5, leftCircle2, rollingPinView5);
        }
    }
    
    public void processMouseDrag8(MouseEvent event) {
        if (event.getSource() == rollingPinView6) { 
            double newX = event.getX();
            double newY = event.getY();
            rollingPinView6.setX(newX);
            rollingPinView6.setY(newY);
            pinCircle.setCenterX(newX + 950);
            pinCircle.setCenterY(newY + 400);
        }
        if (Shape.intersect(pinCircle, leftCircle3).getBoundsInLocal().isEmpty() == false) {
            getChildren().addAll(rightCircle4, rollingPinView7);
            doughView7.setVisible(true);
            rightCircle4.setVisible(true);
            rollingPinView7.setVisible(true);
            
            getChildren().removeAll(doughView6, rightCircle3, rollingPinView6);
        }
    }
    
    public void processMouseDrag9(MouseEvent event) {
        if (event.getSource() == rollingPinView7) { 
            double newX = event.getX();
            double newY = event.getY();
            rollingPinView7.setX(newX);
            rollingPinView7.setY(newY);
            pinCircle.setCenterX(newX + 450);
            pinCircle.setCenterY(newY + 400);
        }
        if (Shape.intersect(pinCircle, rightCircle4).getBoundsInLocal().isEmpty() == false) {
            getChildren().add(leftCircle4);
            doughView8.setVisible(true);
            leftCircle4.setVisible(true);
            step3Button.setVisible(true);
            
            getChildren().removeAll(doughView7, leftCircle3, rollingPinView7);
        }
    }
    
    public void processButtonPress9(ActionEvent event) {
        if(event.getSource() == step3Button) {
            step3.setVisible(true);
            getChildren().addAll(dough, doughView, butter,
                    butterView, cinSug, cinSugView, frosting, frostingView);
            dough.setVisible(true);
                    doughView.setVisible(true);
                    butter.setVisible(true);
                    butterView.setVisible(true);
                    cinSug.setVisible(true);
                    cinSugView.setVisible(true);
                    frosting.setVisible(true);
                    frostingView.setVisible(true);

            getChildren().removeAll(doughView8, step2, rightCircle4, leftCircle4, pinCircle, step3Button);
            }
    }
    
    //-------------------------------------------------------------------------------------------------------------------------
    // step 3 (event handler for checkboxes)
    
    public void processCheckBoxes2(ActionEvent event) {
            if(cinSug.isSelected() && butter.isSelected()){   
                bowlButterView.setVisible(true);
                measureLabel.setVisible(true);
                measureButterLabel.setVisible(true);
                butterView2.setVisible(true);
                    
                getChildren().removeAll(dough, doughView, butter,
                    butterView, cinSug, cinSugView, frosting, frostingView, step3);
                }    
    }
    
    public void processMouseClick(MouseEvent event) {
        if(event.getSource() == butterView2) {
                bowlCinSugView.setVisible(true);
                measureLabel.setVisible(true);
                measureCinSugLabel.setVisible(true);
                cinSugView2.setVisible(true);
                
            getChildren().removeAll(bowlButterView, measureButterLabel, butterView2);
        }
    }
    
    public void processMouseClick2(MouseEvent event) {
        if(event.getClickCount() == 1 && event.getSource() == cinSugView2) {
            step3b.setVisible(true);
            whiskView.setVisible(true);
            
            getChildren().removeAll(measureCinSugLabel, cinSugView2, measureLabel);
        }
    }
    
    // event handler for dragging the whisk image and circle to the bowl image and circle
    public void processMouseDrag(MouseEvent event) {
        if (event.getSource() == whiskView) { 
            double newX = event.getX();
            double newY = event.getY();
            whiskView.setX(newX);
            whiskView.setY(newY);
            whiskCircle.setCenterX(newX + 150);
            whiskCircle.setCenterY(newY + 200);
        }
        if (Shape.intersect(bowlCircle, whiskCircle).getBoundsInLocal().isEmpty() == false) {
            mixedBowlView.setVisible(true);
            step4Button.setVisible(true);
            getChildren().removeAll(whiskView, whiskCircle, step3, bowlCircle, bowlCinSugView);
        }
    }
    
    // event handler for step 4 button
    public void processButtonPress2(ActionEvent event) {
        if(event.getSource() == step4Button) {
            mixedBowlView.setLayoutX(600);
            mixedBowlView.setLayoutY(100);
            getChildren().add(doughView7);
            doughView7.setVisible(true);
            doughView7.setLayoutX(100);
            doughView7.setLayoutY(300);
            step4b.setVisible(true);
            
            getChildren().removeAll(step4Button, step3b);
            }
    }
    
    //-------------------------------------------------------------------------------------------------------------------------
    // step 4 (event handler for rotating the bowl)
    
    public void processMouseRotate(MouseEvent event) {
        if (event.getSource() == mixedBowlView) {  
                mixedBowlView.setRotate(mixedBowlView.getRotate() - 5);  
            if (event.getClickCount() == 7) {
                cinSugDoughView.setVisible(true);
                cinSugDoughView.setLayoutX(250);
                cinSugDoughView.setLayoutY(300);
                getChildren().removeAll(mixedBowlView, doughView7, step4b);
                step5.setVisible(true);
            }
        }
    }
    
    public void processMouseClick12(MouseEvent event) {
        if(event.getSource() == cinSugDoughView) {
                rollDoughView.setVisible(true);
                
            getChildren().removeAll(cinSugDoughView);
        }
    }
    
    //-------------------------------------------------------------------------------------------------------------------------
    // step 5 (event handler for rolling the dough)
    
    public void processMouseClick11(MouseEvent event) {
        if(event.getSource() == rollDoughView) {
                rollView.setVisible(true);
                step6Button.setVisible(true);
                
            getChildren().removeAll(rollDoughView);
        }
    } 
    
    // event handler for step 6 button
    public void processButtonPress4(ActionEvent event) {
        if(event.getSource() == step6Button) {
            step6.setVisible(true);
            rollView2.setVisible(true);
            cutButton.setVisible(true);
            
            getChildren().removeAll(step6Button, rollView, step5);
            }
    }
    
    //-------------------------------------------------------------------------------------------------------------------------
    // step 6 (event handler for cutting the dough)
    
    public void processButtonPress5(ActionEvent event) {
        if(event.getSource() == cutButton) {
            rollView3.setVisible(true);
            step7Button.setVisible(true);
                    
            getChildren().removeAll(cutButton, rollView2, step6);
            }
    }
    
    // event handler for step7Button
    public void processButtonPress6(ActionEvent event) {
        if(event.getSource() == step7Button) {
            
            step6a.setVisible(true);
            openOvenView.setVisible(true);
            panCircle.setVisible(true);
            ovenCircle.setVisible(true);
            
            uncookedView.setVisible(true);
            uncookedView.setLayoutY(450);
            uncookedView.setLayoutX(50);
                    
            getChildren().removeAll(step7Button, rollView3);
            }
    }
    
    //-------------------------------------------------------------------------------------------------------------------------
    // step 7 (event handler for putting the dough in the oven)
    
    public void processMouseDrag2(MouseEvent event) {
        if (event.getSource() == uncookedView) { 
            double secondX = event.getX();
            double secondY = event.getY();
            uncookedView.setX(secondX);
            uncookedView.setY(secondY);
            panCircle.setCenterX(secondX + 50);
            panCircle.setCenterY(secondY + 550);
        }
        if (Shape.intersect(panCircle, ovenCircle).getBoundsInLocal().isEmpty() == false) {
            ovenTimer.setVisible(true);
            timerTextField.setVisible(true);
            
        }
    }
    
    // event handler for setting the oven timer with textfield
    
    public void processTextField(ActionEvent event) {
        int time = Integer.parseInt(timerTextField.getText());
        if (event.getSource() == timerTextField) {
            if (time == 20) {
            getChildren().removeAll(panCircle, ovenCircle, openOvenView, step6a, ovenTimer, timerTextField, uncookedView);
            step7.setVisible(true);
            cookedView.setVisible(true);
            }
        }
    }
    
    //-------------------------------------------------------------------------------------------------------------------------
    // step 8 (event handler for adding frosting)
   
    public void processKeyType(KeyEvent event) {
        if(event.getSource() == cookedView) {
             if (event.getCharacter().equals("f")) {  
                toppedView.setVisible(true);
                serveButton.setVisible(true);
                
                getChildren().removeAll(cookedView, step7);
                }
            }
        }
    
    //-------------------------------------------------------------------------------------------------------------------------
    // event handler for serving
    
    public void processButtonPress8(ActionEvent event) {
        if(event.getSource() == serveButton) {
            finalView.setVisible(true);
            doneLabel.setVisible(true);
                    
            getChildren().removeAll(toppedView, serveButton);
            }
    }
    
    

}
