package finalprojectgui;

import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

/**
 *
 * @author rebekahkim
 */
public class cRollRecipePane extends FlowPane {
    private Label bLabel;
    private Label ingredients;
    private CheckBox dough;
    private CheckBox sugar;
    private CheckBox butter;
    private CheckBox frosting;
    private Label instructions;
    private CheckBox step1;
    private CheckBox step2;
    private CheckBox step3;
    private CheckBox step4;
    private CheckBox step5;
    private CheckBox step6;
    private CheckBox step7;
    private CheckBox step8;
    private Image crollImage;
    private ImageView crollImageView;
    private Label spacer;
    private Label spacer2;

    public cRollRecipePane() {
        // recipe label
        bLabel = new Label("Cinnamon Roll Recipe");
        Font brownieFont = Font.font("Courier New", FontWeight.BOLD, 26);       
        bLabel.setFont(brownieFont);
        bLabel.setTextFill(Color.DARKSEAGREEN);
        bLabel.setPrefWidth(400);                   
        bLabel.setWrapText(true);  
        
        //-------------------------------------------------------------------------------------------------------------------------
        // ingredients labels
        ingredients = new Label("Ingredients:");
        Font headingFont = Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20);       
        ingredients.setFont(headingFont);
        ingredients.setTextFill(Color.DARKSEAGREEN);
        ingredients.setPrefWidth(400);                   
        ingredients.setWrapText(true);  
        
        dough = new CheckBox("1 ball of premade dough");
        Font ingredientFont = Font.font("Helvetica", FontWeight.BOLD, 16);       
        dough.setFont(ingredientFont);
        dough.setTextFill(Color.DARKSLATEGRAY);
        dough.setPrefWidth(400);                   
        dough.setWrapText(true);
        
        sugar = new CheckBox("1 cup of cinnamon sugar");     
        sugar.setFont(ingredientFont);
        sugar.setTextFill(Color.DARKSLATEGRAY);
        sugar.setPrefWidth(400);                   
        sugar.setWrapText(true);
        
        butter = new CheckBox("1/4 cup metled butter");      
        butter.setFont(ingredientFont);
        butter.setTextFill(Color.DARKSLATEGRAY);
        butter.setPrefWidth(400);                   
        butter.setWrapText(true);
        
        frosting = new CheckBox("1/2 cup cream cheese frosting");      
        frosting.setFont(ingredientFont);
        frosting.setTextFill(Color.DARKSLATEGRAY);
        frosting.setPrefWidth(400);                   
        frosting.setWrapText(true);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // instructions labels
        instructions = new Label("Instructions:");   
        instructions.setFont(headingFont);
        instructions.setTextFill(Color.DARKSEAGREEN);
        instructions.setPrefWidth(400);                   
        instructions.setWrapText(true);  
        
        step1 = new CheckBox("1. Preheat oven to 400 degrees.");      
        step1.setFont(ingredientFont);
        step1.setTextFill(Color.DARKSLATEGRAY);
        step1.setPrefWidth(400);                   
        step1.setWrapText(true);
        
        step2 = new CheckBox("2. Roll dough into a 1/2 inch thick rectangle");      
        step2.setFont(ingredientFont);
        step2.setTextFill(Color.DARKSLATEGRAY);
        step2.setPrefWidth(400);                   
        step2.setWrapText(true);
        
        step3 = new CheckBox("3. Combine cinnamon sugar and melted butter.");      
        step3.setFont(ingredientFont);
        step3.setTextFill(Color.DARKSLATEGRAY);
        step3.setPrefWidth(400);                   
        step3.setWrapText(true);
        
        step4 = new CheckBox("4. Spread mixture onto the dough in an even layer.");      
        step4.setFont(ingredientFont);
        step4.setTextFill(Color.DARKSLATEGRAY);
        step4.setPrefWidth(400);                   
        step4.setWrapText(true);
        
        step5 = new CheckBox("5. Roll dough around the filling to make a log shape.");      
        step5.setFont(ingredientFont);
        step5.setTextFill(Color.DARKSLATEGRAY);
        step5.setPrefWidth(400);                   
        step5.setWrapText(true);
        
        step6 = new CheckBox("6. Cut log into even rolls.");      
        step6.setFont(ingredientFont);
        step6.setTextFill(Color.DARKSLATEGRAY);
        step6.setPrefWidth(400);                   
        step6.setWrapText(true);
        
        step7 = new CheckBox("7. Place the rolls in the oven for 20 minutes.");      
        step7.setFont(ingredientFont);
        step7.setTextFill(Color.DARKSLATEGRAY);
        step7.setPrefWidth(400);                   
        step7.setWrapText(true);
        
        step8 = new CheckBox("8. Remove from oven and cover the tops \n  of the rolls with cream cheese.");      
        step8.setFont(ingredientFont);
        step8.setTextFill(Color.DARKSLATEGRAY);
        step6.setPrefWidth(400);                   
        step8.setWrapText(true);
        
        getChildren().addAll(bLabel, ingredients, dough, sugar, butter, frosting, 
                instructions, step1, step2, step3, step4, step5, step6, step7, step8);
        
        //-------------------------------------------------------------------------------------------------------------------------
        // image display
        spacer = new Label("");
        spacer.setPrefWidth(400);
        getChildren().add(spacer);
        
        spacer2 = new Label("");
        spacer2.setPrefWidth(100);
        getChildren().add(spacer2);
        
        crollImage = new Image("file:cinnamonroll.jpg");
        crollImageView = new ImageView(crollImage);
        crollImageView.setPreserveRatio(true);                                                             
        crollImageView.setFitWidth(200); 
        getChildren().add(crollImageView);
    }
    
}
